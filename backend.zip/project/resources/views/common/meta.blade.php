<meta charset="utf-8">
        <meta http-equiv="x-ua-compatible" content="ie=edge">
        <title>{{$gs->title}}</title>
        <meta name="description" content="{{$gs->title}}">
        <meta name="viewport" content="width=device-width, initial-scale=1">

		<link rel="shortcut icon" type="image/x-icon" href="{{getPhoto($gs->favicon)}}">
        <!-- Place favicon.ico in the root directory -->