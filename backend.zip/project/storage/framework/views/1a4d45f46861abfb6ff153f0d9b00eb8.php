
<?php $__env->startSection('title'); ?>
<?php echo app('translator')->get('Add New Volunteer'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('breadcrumb'); ?>
<section class="section">
    <div class="section-header  d-flex justify-content-between">
        <h1><?php echo app('translator')->get('Add New Volunteer'); ?></h1>
        <a href="<?php echo e(route('admin.volunteer.index')); ?>" class="btn btn-primary"><i class="fas fa-backward"></i>
            <?php echo app('translator')->get('Back'); ?></a>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

<div class="row justify-content-center">
    <div class="col-md-12">
        <!-- Form Basic -->
        <div class="card mb-4">
            <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                <h6 class="m-0 font-weight-bold text-primary"><?php echo e(__('Add New Volunteer Form')); ?></h6>
            </div>
            <div class="card-body">

                <form action="<?php echo e(route('admin.volunteer.store')); ?>" enctype="multipart/form-data" method="POST">
                    <?php echo csrf_field(); ?>
                    <div class="form-group d-flex justify-content-center">
                        <div id="image-preview" class="image-preview image-preview_alt"
                            style="background-image:url(<?php echo e(getPhoto($gs->header_logo)); ?>);">
                            <label for="image-upload" id="image-label"><?php echo app('translator')->get('Choose File'); ?></label>
                            <input type="file" name="header_logo" id="image-upload" />
                        </div>
                    </div>

                    <div class="form-group">
                        <label for="name"><?php echo e(__('Name')); ?></label>
                        <input type="text" class="form-control" name="name" id="name" required
                            placeholder="<?php echo e(__('Name')); ?>" value="<?php echo e(old('name')); ?>">
                    </div>


                    <div class="form-group">
                        <label for="designation"><?php echo e(__('Designation')); ?></label>
                        <textarea id="area1" class="form-control summernote" name="designation"
                            placeholder="<?php echo e(__('Designation')); ?>" required><?php echo e(old('designation')); ?></textarea>
                    </div>


                    <button type="submit" class="btn btn-primary"><?php echo e(__('Submit')); ?></button>
                </form>
            </div>
        </div>
        <!-- Form Sizing -->
        <!-- Horizontal Form -->
    </div>
</div>
<!--Row-->
<?php $__env->stopSection(); ?>

<?php $__env->startPush('script'); ?>
<script>
    'use strict';

    $.uploadPreview({
                input_field: "#image-upload", // Default: .image-upload
                preview_box: "#image-preview", // Default: .image-preview
                label_field: "#image-label", // Default: .image-label
                label_default: "<?php echo e(__('Choose File')); ?>", // Default: Choose File
                label_selected: "<?php echo e(__('Update Image')); ?>", // Default: Change File
                no_label: false, // Default: false
                success_callback: null // Default: null
            });
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\charity-new\project\resources\views/admin/volunteer/create.blade.php ENDPATH**/ ?>