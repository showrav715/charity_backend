<?php $__env->startSection('title'); ?>
    <?php echo app('translator')->get('Role'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('breadcrumb'); ?>
    <section class="section">
        <div class="section-header">
            <h1><?php echo app('translator')->get('Role'); ?></h1>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-lg-12">
            <div class="card mb-4">
                <div class="card-header d-flex justify-content-end">
                    <a href="<?php echo e(route('admin.role.create')); ?>" class="btn btn-primary">
                        <i class="fas fa-plus"></i> <?php echo app('translator')->get('Add New'); ?>
                    </a>

                </div>
                <div class="table-responsive p-3">
                    <table class="table table-striped">
                        <tr>
                            <th><?php echo app('translator')->get('Name'); ?></th>
                            <th><?php echo app('translator')->get('Permission'); ?></th>
                            <th class="text-right"><?php echo app('translator')->get('Action'); ?></th>
                        </tr>
                        <?php $__empty_1 = true; $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td data-label="<?php echo app('translator')->get('Name'); ?>">
                                    <?php echo e($item->name); ?>

                                </td>
                                <td data-label="<?php echo app('translator')->get('Permission'); ?>">
                                    <?php if($item->section): ?>
                                        <?php $__currentLoopData = json_decode($item->section); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <span class="badge badge-success"> <?php echo e($permission); ?> </span>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endif; ?>
                                </td>
                                <td data-label="<?php echo app('translator')->get('Action'); ?>" class="text-right">
                                    <a href="<?php echo e(route('admin.role.edit', $item->id)); ?>" class="btn btn-primary btn-sm mb-1"
                                        title="<?php echo app('translator')->get('Edit'); ?>"><i class="fas fa-edit"></i></a>
                                    <a href="javascript:void(0)" class="btn btn-danger btn-sm remove mb-1"
                                        data-id="<?php echo e($item->id); ?>" data-toggle="tooltip" title="<?php echo app('translator')->get('Remove'); ?>"><i
                                            class="fas fa-trash"></i></a>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td class="text-center" colspan="100%"><?php echo app('translator')->get('No Data Found'); ?></td>
                            </tr>
                        <?php endif; ?>
                    </table>
                </div>
            </div>
        </div>
    </div>



    <div class="modal fade" id="removeMod" tabindex="-1" role="dialog">
        <div class="modal-dialog" role="document">
            <form action="<?php echo e(route('admin.role.destroy')); ?>" method="POST">
                <?php echo method_field('DELETE'); ?>
                <?php echo csrf_field(); ?>
                <input type="hidden" name="id">
                <div class="modal-content">
                    <div class="modal-body">
                        <h5><?php echo app('translator')->get('Are you sure to remove?'); ?></h5>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-dark" data-dismiss="modal"><?php echo app('translator')->get('Close'); ?></button>
                        <button type="submit" class="btn btn-danger"><?php echo app('translator')->get('Confirm'); ?></button>
                    </div>
                </div>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('script'); ?>
    <script>
        'use strict';
        $('.remove').on('click', function() {
            $('#removeMod').find('input[name=id]').val($(this).data('id'))
            $('#removeMod').modal('show')
        })
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\charity\backend\project\resources\views/admin/role/index.blade.php ENDPATH**/ ?>