<aside id="sidebar-wrapper">
    <ul class="sidebar-menu mb-5">
        <li class="menu-header"><?php echo app('translator')->get('Dashboard'); ?></li>
        <li class="nav-item <?php echo e(menu('admin.dashboard')); ?>">
            <a href="<?php echo e(route('admin.dashboard')); ?>" class="nav-link"><i
                    class="fas fa-fire"></i><span><?php echo app('translator')->get('Dashboard'); ?></span></a>
        </li>

        <?php if(access('Services')): ?>
            <li class="nav-item dropdown <?php echo e(menu(['admin.service*'])); ?>">
                <a href="#" class="nav-link has-dropdown" data-toggle="dropdown">
                    <i class="fas fa-toolbox"></i>
                    <span><?php echo app('translator')->get('Services'); ?></span></a>
                <ul class="dropdown-menu">
                    <li class="<?php echo e(menu('admin.service.index')); ?>"><a class="nav-link"
                            href="<?php echo e(route('admin.service.index')); ?>"><?php echo app('translator')->get('Service'); ?></a></li>
                    <li class="<?php echo e(menu('admin.service.faq.index')); ?>"><a class="nav-link"
                            href="<?php echo e(route('admin.service.faq.index')); ?>"><?php echo app('translator')->get('Service Faq'); ?></a></li>
                </ul>
            </li>
        <?php endif; ?>


        <?php if(access('Manage Contact')): ?>
            <li class="nav-item dropdown <?php echo e(menu(['admin.contact*'])); ?>">
                <a href="#" class="nav-link has-dropdown" data-toggle="dropdown"><i
                        class="fas fa-envelope-open-text"></i></i>
                    <span><?php echo app('translator')->get('Manage Contact'); ?></span></a>
                <ul class="dropdown-menu">
                    <li class="<?php echo e(menu('admin.contact.getintouch.message')); ?>"><a class="nav-link"
                            href="<?php echo e(route('admin.contact.getintouch.message')); ?>"><?php echo app('translator')->get('Get in Touch'); ?></a>
                    </li>
                    <li class="<?php echo e(menu('admin.contact.message')); ?>"><a class="nav-link"
                            href="<?php echo e(route('admin.contact.message')); ?>"><?php echo app('translator')->get('Contact Messages'); ?></a>
                    </li>
                    <li class="<?php echo e(menu('admin.contact.setting.index')); ?>"><a class="nav-link"
                            href="<?php echo e(route('admin.contact.setting.index')); ?>"><?php echo app('translator')->get('Contact Setting'); ?></a></li>
                </ul>
            </li>
        <?php endif; ?>



        <?php if(access('Blogs')): ?>
            <li class="nav-item dropdown <?php echo e(menu(['admin.bcategory*', 'admin.blog*'])); ?>">
                <a href="#" class="nav-link has-dropdown" data-toggle="dropdown"><i class="fab fa-blogger-b"></i>
                    <span><?php echo app('translator')->get('Blogs'); ?></span></a>
                <ul class="dropdown-menu">
                    <li class="<?php echo e(menu('admin.bcategory.index')); ?>"><a class="nav-link"
                            href="<?php echo e(route('admin.bcategory.index')); ?>"><?php echo app('translator')->get('Category'); ?></a></li>
                    <li class="<?php echo e(menu('admin.blog.index')); ?>"><a class="nav-link"
                            href="<?php echo e(route('admin.blog.index')); ?>"><?php echo app('translator')->get('Blogs'); ?></a>
                    </li>
                </ul>
            </li>
        <?php endif; ?>


        <?php if(access('Manage Project')): ?>
            <li class="nav-item dropdown <?php echo e(menu(['admin.pcategory*','admin.project*'])); ?>">
                <a href="#" class="nav-link has-dropdown" data-toggle="dropdown"><i class="fab fa-r-project"></i>
                    <span><?php echo app('translator')->get('Manage Project'); ?></span></a>
                <ul class="dropdown-menu">

                    <li class="<?php echo e(menu('admin.pcategory.index')); ?>"><a class="nav-link"
                            href="<?php echo e(route('admin.pcategory.index')); ?>"><?php echo app('translator')->get('Category'); ?></a>
                    </li>
                    <li class="<?php echo e(menu('admin.project.index')); ?>"><a class="nav-link"
                            href="<?php echo e(route('admin.project.index')); ?>"><?php echo app('translator')->get('Project'); ?></a></li>
                </ul>
            </li>
        <?php endif; ?>

        <?php if(access('Manage Pages')): ?>
            <li class="nav-item <?php echo e(menu('admin.page.index*')); ?>">
                <a href="<?php echo e(route('admin.page.index')); ?>" class="nav-link"><i
                        class="fas fa-file-alt"></i><span><?php echo app('translator')->get('Manage Pages'); ?></span></a>
            </li>
        <?php endif; ?>


        <?php if(access('Manage Team')): ?>
            <li class="nav-item <?php echo e(menu('admin.team.index')); ?>">
                <a href="<?php echo e(route('admin.team.index')); ?>" class="nav-link"><i class="fas fa-users-cog"></i>
                    <span><?php echo app('translator')->get('Manage Team'); ?></span></a>
            </li>
        <?php endif; ?>




        <?php if(access('General Settings')): ?>
            <li class="menu-header"><?php echo app('translator')->get('General Settings'); ?></li>

            <li class="nav-item dropdown <?php echo e(menu(['admin.gs*','admin.social.manage*','admin.language*', 'admin.cookie'])); ?>">
                <a href="#" class="nav-link has-dropdown" data-toggle="dropdown"><i
                        class="fas fa-cog"></i><span><?php echo app('translator')->get('General Settings'); ?></span></a>
                <ul class="dropdown-menu">

                    <li class="<?php echo e(menu('admin.gs.site.settings')); ?>"><a class="nav-link"
                            href="<?php echo e(route('admin.gs.site.settings')); ?>"><?php echo app('translator')->get('Site Settings'); ?></a></li>
                    <li class="<?php echo e(menu('admin.gs.theme.settings')); ?>"><a class="nav-link"
                            href="<?php echo e(route('admin.gs.theme.settings')); ?>"><?php echo app('translator')->get('Theme Settings'); ?></a></li>
                    <li class="<?php echo e(menu('admin.gs.logo')); ?>"><a class="nav-link"
                            href="<?php echo e(route('admin.gs.logo')); ?>"><?php echo app('translator')->get('Logo & Favicon'); ?></a></li>
                    <li class="<?php echo e(menu('admin.gs.breadcumb')); ?>"><a class="nav-link"
                            href="<?php echo e(route('admin.gs.breadcumb')); ?>"><?php echo app('translator')->get('Breadcumb'); ?></a></li>
                    <li class="<?php echo e(menu('admin.social.manage')); ?>"><a class="nav-link"
                            href="<?php echo e(route('admin.social.manage')); ?>"><?php echo app('translator')->get('Social Links'); ?></a></li>
                    <li class="<?php echo e(menu('admin.cookie')); ?>"><a class="nav-link"
                            href="<?php echo e(route('admin.cookie')); ?>"><?php echo app('translator')->get('Cookie Concent'); ?></a></li>
                    <li class="<?php echo e(menu('admin.gs.plugin.settings')); ?>"><a class="nav-link"
                            href="<?php echo e(route('admin.gs.plugin.settings')); ?>"><?php echo app('translator')->get('Plugins'); ?></a></li>
                    <li class="<?php echo e(menu('admin.gs.maintainance.settings')); ?>"><a class="nav-link"
                            href="<?php echo e(route('admin.gs.maintainance.settings')); ?>"><?php echo app('translator')->get('Maintenance'); ?></a></li>
                </ul>
            </li>
        <?php endif; ?>



        <?php if(access('Frontend Settings')): ?>
            <li
                class="nav-item dropdown <?php echo e(menu(['admin.front*', 'admin.faq*', 'admin.testimonial*', 'admin.brand*', 'admin.contact.section', 'admin.about*', 'admin.slider*', 'admin.counter*', 'admin.frontend*'])); ?>">
                <a href="#" class="nav-link has-dropdown"><i class="fas fa-th"></i>
                    <span><?php echo app('translator')->get('Frontend Setting'); ?></span></a>
                <ul class="dropdown-menu">
                    <li class="<?php echo e(menu('admin.slider.index')); ?>"><a class="nav-link"
                            href="<?php echo e(route('admin.slider.index')); ?>"><?php echo app('translator')->get('Slider'); ?></a></li>
                    <li class="<?php echo e(menu('admin.about.index')); ?>"><a class="nav-link"
                            href="<?php echo e(route('admin.about.index')); ?>"><?php echo app('translator')->get('About'); ?></a></li>
                    <li class="<?php echo e(menu('admin.counter.index')); ?>"><a class="nav-link"
                            href="<?php echo e(route('admin.counter.index')); ?>"><?php echo app('translator')->get('Counter Section'); ?></a></li>
                    <li class="<?php echo e(menu('admin.faq.index')); ?>"><a class="nav-link"
                            href="<?php echo e(route('admin.faq.index')); ?>"><?php echo app('translator')->get('FAQ'); ?></a></li>
                    <li class="<?php echo e(menu('admin.contact.section')); ?>"><a class="nav-link"
                            href="<?php echo e(route('admin.contact.section')); ?>"><?php echo app('translator')->get('Contact Section'); ?></a></li>
                    <li class="<?php echo e(menu('admin.testimonial.index')); ?>"><a class="nav-link"
                            href="<?php echo e(route('admin.testimonial.index')); ?>"><?php echo app('translator')->get('Testimonials'); ?></a></li>
                    <li class="<?php echo e(menu('admin.brand.index')); ?>"><a class="nav-link"
                            href="<?php echo e(route('admin.brand.index')); ?>"><?php echo app('translator')->get('Brand'); ?></a></li>
                </ul>
            </li>
        <?php endif; ?>



        <?php if(access('Manage Role')): ?>
            <li class="nav-item <?php echo e(menu('admin.role*')); ?>">
                <a href="<?php echo e(route('admin.role.index')); ?>" class="nav-link"><i
                        class="far fa-question-circle"></i><span><?php echo app('translator')->get('Manage Role'); ?></span></a>
            </li>
        <?php endif; ?>


        <?php if(access('Manage Staff')): ?>
            <li class="nav-item <?php echo e(menu('admin.staff*')); ?>">
                <a href="<?php echo e(route('admin.staff.manage')); ?>" class="nav-link"><i
                        class="fas fa-user-shield"></i><span><?php echo app('translator')->get('Manage Staff'); ?></span></a>
            </li>
        <?php endif; ?>



        <?php if(access('Subscribers')): ?>
            <li class="nav-item <?php echo e(menu('admin.subscriber')); ?>">
                <a href="<?php echo e(route('admin.subscriber')); ?>" class="nav-link"><i class="fas fa-users"></i>
                    <span><?php echo app('translator')->get('Subscribers'); ?></span></a>
            </li>
        <?php endif; ?>


        <li class="nav-item <?php echo e(menu('admin.clear.cache')); ?>">
            <a href="<?php echo e(route('admin.clear.cache')); ?>" class="nav-link"><i class="fas fa-broom"></i>
                <span><?php echo app('translator')->get('Clear Cache'); ?></span></a>
        </li>


    </ul>
</aside>
<?php /**PATH C:\xampp\htdocs\car-service\project\resources\views/admin/partials/staff_sitebar.blade.php ENDPATH**/ ?>