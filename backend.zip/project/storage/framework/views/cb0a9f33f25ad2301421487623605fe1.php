
<?php $__env->startSection('title'); ?>
    <?php echo app('translator')->get('Add Role'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('breadcrumb'); ?>
    <section class="section">
        <div class="section-header d-flex justify-content-between">
            <h1><?php echo app('translator')->get('Add Role'); ?></h1>
            <a href="<?php echo e(route('admin.role.index')); ?>" class="btn btn-primary"><i class="fas fa-backward"></i> <?php echo app('translator')->get('Back'); ?>
            </a>
        </div>
    </section>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="row justify-content-center">
        <div class="col-md-12">
            <div class="card mb-4">
                <div class="card-body">

                    <form action="<?php echo e(route('admin.role.store')); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <div class="form-group">
                            <label><?php echo app('translator')->get('Name'); ?></label>
                            <input class="form-control" type="text" name="name">
                        </div>
                        <div class="form-group">
                            <label><?php echo app('translator')->get('Permission'); ?></label>
                            <select name="section[]" class="select2" multiple>
                                <option value="Services"><?php echo app('translator')->get('Services'); ?></option>
                                <option value="Manage Contact"><?php echo app('translator')->get('Manage Contact'); ?></option>
                                <option value="Blogs"><?php echo app('translator')->get('Blogs'); ?></option>
                                <option value="Manage Project"><?php echo app('translator')->get('Manage Project'); ?></option>
                                <option value="Manage Pages"><?php echo app('translator')->get('Manage Pages'); ?></option>
                                <option value="General Settings"><?php echo app('translator')->get('General Settings'); ?></option>
                                <option value="Frontend Settings"><?php echo app('translator')->get('Frontend Settings'); ?></option>
                                <option value="Manage Role"><?php echo app('translator')->get('Manage Role'); ?></option>
                                <option value="Manage Staff"><?php echo app('translator')->get('Manage Staff'); ?></option>
                                <option value="Subscribers"><?php echo app('translator')->get('Subscribers'); ?></option>
                            </select>
                        </div>
                        <button type="submit" class="btn btn-primary"><?php echo e(__('Submit')); ?></button>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <!--Row-->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\car-service\project\resources\views/admin/role/create.blade.php ENDPATH**/ ?>