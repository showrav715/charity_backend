
<?php $__env->startSection('title'); ?>
<?php echo app('translator')->get('Edit About Section'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('breadcrumb'); ?>
<section class="section">
    <div class="section-header d-flex justify-content-between">
        <h1><?php echo app('translator')->get('Edit About Section'); ?></h1>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="row justify-content-center">
    <div class="col-md-12">
        <div class="card mb-4">
            <div class="card-body">

                <form action="<?php echo e(route('admin.about.update')); ?>" method="POST" enctype="multipart/form-data">
                    <?php echo method_field('PUT'); ?>
                    <?php echo csrf_field(); ?>

                    <div class="row">

                        <div class="col-8 offset-2 text-center">
                            <label for="">Photo</label>
                            <div class="form-group d-flex justify-content-center">
                                <div id="image-preview_about" class="image-preview image-preview_alt"
                                    style="background-image:url(<?php echo e(getPhoto($about->photo)); ?>);">
                                    <label for="image-upload_about" id="image-label_about"><?php echo app('translator')->get('Choose File'); ?></label>
                                    <input type="file" name="photo" id="image-upload_about" />
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="form-group">
                        <label><?php echo app('translator')->get('Header Title'); ?></label>
                        <input class="form-control" type="text" name="header_title" value="<?php echo e($about->header_title); ?>">
                    </div>
                    <div class="form-group">
                        <label><?php echo app('translator')->get('Title'); ?></label>
                        <input class="form-control" type="text" name="title" value="<?php echo e($about->title); ?>">
                    </div>

                    <div class="form-group">
                        <label><?php echo app('translator')->get('Description'); ?></label>
                        <textarea name="description" class="form-control summernote"
                            rows="4"><?php echo e($about->description); ?></textarea>
                    </div>

                    <div class="form-group">
                        <label><?php echo app('translator')->get('Youtube Video Id'); ?></label>
                        <input class="form-control" type="text" name="video_id" value="<?php echo e($about->video_id); ?>">
                    </div>

                    <div class="form-group">
                        <label><?php echo app('translator')->get('Button Text'); ?></label>
                        <input class="form-control" type="text" name="btn_text" value="<?php echo e($about->btn_text); ?>">
                    </div>
                   
                    <div class="form-group">
                        <label><?php echo app('translator')->get('Button Url'); ?></label>
                        <input class="form-control" type="text" name="btn_url" value="<?php echo e($about->btn_url); ?>">
                    </div>

                    <button type="submit" class="btn btn-primary"><?php echo e(__('Submit')); ?></button>
                </form>
            </div>
        </div>
    </div>
</div>

<div class="row">
    <div class="col-lg-12">
        <div class="card mb-4">
            <div class="card-header d-flex justify-content-between">
                <h5><?php echo app('translator')->get('About Featured'); ?></h5>
                <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#add">
                    <i class="fas fa-plus"></i> <?php echo app('translator')->get('Add New'); ?>
                </button>

            </div>
            <div class="table-responsive p-3">
                <table class="table table-striped">
                    <tr>
                        <th><?php echo app('translator')->get('Photo'); ?></th>
                        <th><?php echo app('translator')->get('Title'); ?></th>
                        <th><?php echo app('translator')->get('Text'); ?></th>
                        <th class="text-right"><?php echo app('translator')->get('Action'); ?></th>
                    </tr>
                    <?php $__empty_1 = true; $__currentLoopData = $features; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>

                        <td data-label="<?php echo app('translator')->get('Photo'); ?>">
                            <img src="<?php echo e(getPhoto($item->photo)); ?>" class="img-fluid" style="width: 50px" alt="">
                        </td>
                        <td data-label="<?php echo app('translator')->get('Title'); ?>">
                            <?php echo e($item->title); ?>

                        </td>
                        <td data-label="<?php echo app('translator')->get('Text'); ?>">
                            <?php echo e($item->text); ?>

                        </td>

                        <td data-label="<?php echo app('translator')->get('Action'); ?>" class="text-right">
                            <a href="javascript:void()" class="btn btn-primary approve btn-sm edit mb-1"
                                data-route="<?php echo e(route('admin.feature.update',$item->id)); ?>" data-path="<?php echo e(adminpath()); ?>"
                                data-item="<?php echo e($item); ?>" data-toggle="tooltip" title="<?php echo app('translator')->get('Edit'); ?>"><i
                                    class="fas fa-edit"></i></a>
                            <a href="javascript:void(0)" class="btn btn-danger btn-sm remove mb-1"
                                data-id="<?php echo e($item->id); ?>" data-toggle="tooltip" title="<?php echo app('translator')->get('Remove'); ?>"><i
                                    class="fas fa-trash"></i></a>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

                    <tr>
                        <td class="text-center" colspan="100%"><?php echo app('translator')->get('No Data Found'); ?></td>
                    </tr>

                    <?php endif; ?>
                </table>
            </div>
        </div>
    </div>
</div>

<!-- Modal -->
<div class="modal fade" id="add" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <form action="<?php echo e(route('admin.feature.store')); ?>" method="POST" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title"><?php echo app('translator')->get('Add Feature'); ?></h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <div class="form-group">
                        <label><?php echo app('translator')->get('Feature Icon'); ?></label>
                        <div class="form-group d-flex justify-content-center">
                            <div id="image-preview" class="image-preview image-preview_alt" style="">
                                <label for="image-upload" id="image-label"><?php echo app('translator')->get('Choose File'); ?></label>
                                <input type="file" name="photo" id="image-upload" />
                            </div>
                        </div>
                    </div>
                    <div class="form-group">
                        <label><?php echo app('translator')->get('Title'); ?></label>
                        <input class="form-control" type="text" name="title">
                    </div>
                    <div class="form-group">
                        <label><?php echo app('translator')->get('Text'); ?></label>
                        <input class="form-control" type="text" name="text">
                    </div>

                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-dark" data-dismiss="modal"><?php echo app('translator')->get('Close'); ?></button>
                    <button type="submit" class="btn btn-primary"><?php echo app('translator')->get('Submit'); ?></button>
                </div>
            </div>
        </form>
    </div>
</div>

<div class="modal fade" id="edit" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <form action="" method="POST" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title"><?php echo app('translator')->get('Edit Feature'); ?></h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <div class="form-group">
                        <label><?php echo app('translator')->get('Feature Icon'); ?></label>
                        <div class="form-group d-flex justify-content-center">
                            <div id="image-preview1" class="image-preview image-preview_alt" style="">
                                <label for="image-upload1" id="image-label1"><?php echo app('translator')->get('Choose File'); ?></label>
                                <input type="file" name="photo" id="image-upload1" />
                            </div>
                        </div>
                    </div>
                    <div class="form-group">
                        <label><?php echo app('translator')->get('Title'); ?></label>
                        <input class="form-control" type="text" name="title">
                    </div>
                    <div class="form-group">
                        <label><?php echo app('translator')->get('Text'); ?></label>
                        <input class="form-control" type="text" name="text">
                    </div>

                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-dark" data-dismiss="modal"><?php echo app('translator')->get('Close'); ?></button>
                    <button type="submit" class="btn btn-primary"><?php echo app('translator')->get('Submit'); ?></button>
                </div>
            </div>
        </form>
    </div>
</div>


<!-- Modal -->
<div class="modal fade" id="removeMod" tabindex="-1" role="dialog">
    <div class="modal-dialog" role="document">
        <form action="<?php echo e(route('admin.feature.destroy')); ?>" method="POST">
            <?php echo method_field('DELETE'); ?>
            <?php echo csrf_field(); ?>
            <input type="hidden" name="id">
            <div class="modal-content">
                <div class="modal-body">
                    <h5><?php echo app('translator')->get('Are you sure to remove?'); ?></h5>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-dark" data-dismiss="modal"><?php echo app('translator')->get('Close'); ?></button>
                    <button type="submit" class="btn btn-danger"><?php echo app('translator')->get('Confirm'); ?></button>
                </div>
            </div>
        </form>
    </div>
</div>


<!--Row-->
<?php $__env->stopSection(); ?>

<?php $__env->startPush('script'); ?>
<?php $__env->startPush('script'); ?>
<script>
    'use strict';

   $.uploadPreview({
            input_field: "#image-upload_about",
            preview_box: "#image-preview_about",
            label_field: "#image-label_about",
            label_default: "<?php echo e(__('Choose File')); ?>",
            label_selected: "<?php echo e(__('Update Image')); ?>",
            no_label: false,
            success_callback: null
        });



   $.uploadPreview({
            input_field: "#image-upload",
            preview_box: "#image-preview",
            label_field: "#image-label",
            label_default: "<?php echo e(__('Choose File')); ?>",
            label_selected: "<?php echo e(__('Update Image')); ?>",
            no_label: false,
            success_callback: null
        });
        $.uploadPreview({
            input_field: "#image-upload1",
            preview_box: "#image-preview1",
            label_field: "#image-label1",
            label_default: "<?php echo e(__('Choose File')); ?>",
            label_selected: "<?php echo e(__('Update Image')); ?>",
            no_label: false,
            success_callback: null
        });

       $('.edit').on('click',function () { 
          var data = $(this).data('item');
          $('#edit').find('input[name=title]').val(data.title);
          $('#edit').find('input[name=text]').val(data.text);
            $('#edit').find('form').attr('action',$(this).data('route'));
            let path = $(this).attr('data-path');
            $('#edit').find('#image-preview1').css('background-image', `url('${path}/${data.photo}')`);
             $('#edit').modal('show');
       })

       $('.remove').on('click',function () { 
         $('#removeMod').find('input[name=id]').val($(this).data('id'))
         $('#removeMod').modal('show')
       })
</script>
<?php $__env->stopPush(); ?>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\charity\backend\project\resources\views/admin/about/index.blade.php ENDPATH**/ ?>