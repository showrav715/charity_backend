

<?php $__env->startSection('title'); ?>
   <?php echo app('translator')->get('Manage Staff'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('breadcrumb'); ?>
 <section class="section">
    <div class="section-header justify-content-between">
        <h1> <?php echo app('translator')->get('Manage Staff'); ?></h1>
  
            <a href="javascript:void(0)" data-toggle="modal" data-target="#addModal" class="btn btn-primary btn-sm add"><i class="fas fa-plus"></i> <?php echo app('translator')->get('Add New Staff'); ?></a>
   
    </div>
</section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-12 col-md-12 col-lg-12">
        <div class="card">
            <div class="card-body text-center">
                <div class="table-responsive">
                    <table class="table table-striped">
                        <tr>
                            <th><?php echo app('translator')->get('Sl'); ?></th>
                            <th><?php echo app('translator')->get('Name'); ?></th>
                            <th><?php echo app('translator')->get('Email'); ?></th>
                            <th><?php echo app('translator')->get('Role'); ?></th>
                            <th><?php echo app('translator')->get('Status'); ?></th>
                            <th><?php echo app('translator')->get('Action'); ?></th>
                        </tr>
                        
                        <?php $__empty_1 = true; $__currentLoopData = $staffs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                          
                            <tr>
                                <td data-label="<?php echo app('translator')->get('Sl'); ?>"><?php echo e($key + $staffs->firstItem()); ?></td>
                    
                                 <td data-label="<?php echo app('translator')->get('Name'); ?>">
                                   <?php echo e($user->name); ?>

                                 </td>
                                 <td data-label="<?php echo app('translator')->get('Email'); ?>"><?php echo e($user->email); ?></td>
                                 <td data-label="<?php echo app('translator')->get('Role'); ?>">
                                     <span class="badge badge-dark"><?php echo e(strtoupper($user->role)); ?></span>
                                 </td>
                                 <td data-label="<?php echo app('translator')->get('Status'); ?>">
                                    <?php if($user->status == 1): ?>
                                        <span class="badge badge-success"><?php echo app('translator')->get('active'); ?></span>
                                    <?php elseif($user->status == 2): ?>
                                         <span class="badge badge-danger"><?php echo app('translator')->get('banned'); ?></span>
                                    <?php endif; ?>
                                 </td>
                                <td data-label="<?php echo app('translator')->get('Action'); ?>">
                                    <a class="btn btn-primary btn-sm details" data-staff="<?php echo e($user); ?>" href="javascript:void(0)" data-route="<?php echo e(route('admin.staff.update',$user->id)); ?>"><?php echo app('translator')->get('Details'); ?></a>
                                    <a href="javascript:void(0)" class="btn btn-danger btn-sm remove mb-1"
                                        data-id="<?php echo e($user->id); ?>" data-toggle="tooltip" title="<?php echo app('translator')->get('Remove'); ?>"><i
                                            class="fas fa-trash"></i></a>
                                </td>
                               
                            </tr>
                         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

                            <tr>
                                <td class="text-center" colspan="100%"><?php echo app('translator')->get('No Data Found'); ?></td>
                            </tr>

                        <?php endif; ?>
                    </table>
                </div>
            </div>
            <?php if($staffs->hasPages()): ?>
                <?php echo e($staffs->links('admin.partials.paginate')); ?>

            <?php endif; ?>
        </div>
    </div>
</div>

<!-- Modal -->
<div class="modal fade" id="removeMod" tabindex="-1" role="dialog">
    <div class="modal-dialog" role="document">
        <form action="<?php echo e(route('admin.staff.destroy')); ?>" method="POST">
            <?php echo method_field('DELETE'); ?>
            <?php echo csrf_field(); ?>
            <input type="hidden" name="id">
            <div class="modal-content">
                <div class="modal-body">
                    <h5><?php echo app('translator')->get('Are you sure to remove?'); ?></h5>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-dark" data-dismiss="modal"><?php echo app('translator')->get('Close'); ?></button>
                    <button type="submit" class="btn btn-danger"><?php echo app('translator')->get('Confirm'); ?></button>
                </div>
            </div>
        </form>
    </div>
</div>

<div class="modal fade" id="addModal" tabindex="-1" role="dialog" aria-labelledby="modelTitleId" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <form action="<?php echo e(route('admin.staff.add')); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title"><?php echo app('translator')->get('Add New Staff'); ?></h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                </div>
                <div class="modal-body">
                    <div class="form-group">
                        <label><?php echo app('translator')->get('Name'); ?></label>
                        <input class="form-control" type="text" name="name" required value="<?php echo e(old('name')); ?>">
                    </div>
                    <div class="form-group">
                        <label><?php echo app('translator')->get('Email'); ?></label>
                        <input class="form-control" type="email" name="email" required value="<?php echo e(old('email')); ?>">
                    </div>
                    <div class="form-group">
                        <label><?php echo app('translator')->get('Password'); ?></label>
                        <input class="form-control" type="password" name="password" required>
                    </div>
                    <div class="form-group">
                        <label><?php echo app('translator')->get('Confirm Password'); ?></label>
                        <input class="form-control" type="password" name="password_confirmation" required>
                    </div>
                    <div class="append"></div>
                    <div class="form-group">
                        <label><?php echo app('translator')->get('Select Role'); ?></label>
                        <select name="role" class="form-control">
                            <option value="">Select</option>
                            <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              <option value="<?php echo e($item); ?>"><?php echo e($item); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-dark" data-dismiss="modal"><?php echo app('translator')->get('Close'); ?></button>
                    <button type="submit" class="btn btn-primary"><?php echo app('translator')->get('Submit'); ?></button>
                </div>
            </div>
        </form>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('script'); ?>
    <script>
        'use strict';
        $('.add').on('click',function () { 
            $('#addModal').find('.append').children().remove()
            $('#addModal').find('form')[0].reset();
        })
        $('.details').on('click',function () { 
           
            $('#addModal').find('.modal-title').text("<?php echo app('translator')->get('Edit staff'); ?>")
            $('#addModal').find('input[name=name]').val($(this).data('staff').name)
            $('#addModal').find('input[name=email]').val($(this).data('staff').email)
            $('#addModal').find('input[name=password]').attr('required',false)
            $('#addModal').find('input[name=password_confirmation]').attr('required',false)
            $('#addModal').find('select[name=role]').val($(this).data('staff').role)

            $('#addModal').find('.append').html(`
                <div class="form-group">
                    <label><?php echo app('translator')->get('Status'); ?></label>
                    <select name="status" class="form-control">
                        <option value="1"><?php echo app('translator')->get('Active'); ?></option>
                        <option value="2"><?php echo app('translator')->get('Banned'); ?></option>
                    </select>
                </div>
            `)
            
            $(document).find('select[name=status]').val($(this).data('staff').status)
            $('#addModal').find('form').attr('action',$(this).data('route'))
            $('#addModal').modal('show');
        })

        $('.remove').on('click', function() {
            $('#removeMod').find('input[name=id]').val($(this).data('id'))
            $('#removeMod').modal('show')
        })
        
    </script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\charity-new\project\resources\views/admin/staff/index.blade.php ENDPATH**/ ?>