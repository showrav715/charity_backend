
<?php $__env->startSection('title'); ?>
<?php echo app('translator')->get('Home Page Section'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('breadcrumb'); ?>
<section class="section">
    <div class="section-header  d-flex justify-content-between">
        <h1><?php echo app('translator')->get('Home Page Section'); ?></h1>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

<div class="row justify-content-center">
    <div class="col-md-12">
        <div class="card mb-4">
            <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                <h6 class="m-0 font-weight-bold text-primary"><?php echo e(__('Home Page Section Update')); ?></h6>
            </div>
            <div class="card-body">
                <form action="<?php echo e(route('admin.home.sections.update')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <div class="form-group">
                        <label for="service_title"><?php echo e(__('Service Title')); ?></label>
                        <input type="text" class="form-control" name="service_title" id="service_title" required
                            placeholder="<?php echo e(__('Service Title')); ?>"
                            value="<?php echo e(old('service_title',$data->service_title)); ?>">
                    </div>

                    <div class="form-group">
                        <label for="service_text"><?php echo e(__('Service Text')); ?></label>
                        <textarea type="text" class="form-control" name="service_text" id="service_text" required
                            placeholder="<?php echo e(__('Service Text')); ?>"><?php echo e($data->service_text); ?></textarea>
                    </div>


                    <div class="form-group">
                        <label for="choose_title"><?php echo e(__('Choose Title')); ?></label>
                        <input type="text" class="form-control" name="choose_title" id="choose_title" required
                            placeholder="<?php echo e(__('Choose Title')); ?>" value="<?php echo e(old('choose_title',$data->choose_title)); ?>">
                    </div>

                    <div class="form-group">
                        <label for="choose_text"><?php echo e(__('Choose Text')); ?></label>
                        <textarea type="text" class="form-control" name="choose_text" id="choose_text" required
                            placeholder="<?php echo e(__('Choose Text')); ?>"><?php echo e($data->choose_text); ?></textarea>
                    </div>


                    <div class="form-group">
                        <label for="team_title"><?php echo e(__('Team Title')); ?></label>
                        <input type="text" class="form-control" name="team_title" id="team_title" required
                            placeholder="<?php echo e(__('Team Title')); ?>" value="<?php echo e(old('team_title',$data->team_title)); ?>">
                    </div>

                    <div class="form-group">
                        <label for="team_text"><?php echo e(__('Team Text')); ?></label>
                        <textarea type="text" class="form-control" name="team_text" id="team_text" required
                            placeholder="<?php echo e(__('Team Text')); ?>"><?php echo e($data->team_text); ?></textarea>
                    </div>


                    <div class="form-group">
                        <label for="testimonial_title"><?php echo e(__('Testimonial Title')); ?></label>
                        <input type="text" class="form-control" name="testimonial_title" id="testimonial_title" required
                            placeholder="<?php echo e(__('Testimonial Title')); ?>"
                            value="<?php echo e(old('testimonial_title',$data->testimonial_title)); ?>">
                    </div>

                    <div class="form-group">
                        <label for="testimonial_text"><?php echo e(__('Testimonial Text')); ?></label>
                        <textarea class="form-control" name="testimonial_text" id="testimonial_text"
                            placeholder="<?php echo e(__('Testimonial Text')); ?>"><?php echo e($data->testimonial_text); ?></textarea>
                    </div>

                    <div class="form-group">
                        <label for="blog_title"><?php echo e(__('Blog Title')); ?></label>
                        <input type="text" class="form-control" name="blog_title" id="blog_title" required
                            placeholder="<?php echo e(__('Blog Title')); ?>" value="<?php echo e(old('blog_title',$data->blog_title)); ?>">
                    </div>

                    <div class="form-group">
                        <label for="blog_text"><?php echo e(__('Blog Text')); ?></label>
                        <textarea class="form-control" name="blog_text" id="blog_text" required
                            placeholder="<?php echo e(__('Blog Text')); ?>"><?php echo e($data->blog_text); ?></textarea>
                    </div>

                    <button type="submit" class="btn btn-primary"><?php echo e(__('Submit')); ?></button>
                </form>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\charity\backend\project\resources\views/admin/generalsetting/home_sections.blade.php ENDPATH**/ ?>