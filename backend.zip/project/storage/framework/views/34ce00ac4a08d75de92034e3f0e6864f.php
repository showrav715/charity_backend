
<?php $__env->startSection('title'); ?>
<?php echo app('translator')->get('Edit Campaign'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('breadcrumb'); ?>
<section class="section">
    <div class="section-header  d-flex justify-content-between">
        <h1><?php echo app('translator')->get('Edit Campaign'); ?></h1>
        <a href="<?php echo e(route('admin.campaign.index')); ?>" class="btn btn-primary"><i class="fas fa-backward"></i>
            <?php echo app('translator')->get('Back'); ?></a>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

<div class="row justify-content-center">
    <div class="col-md-12">
        <!-- Form Basic -->
        <div class="card mb-4">
            <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                <h6 class="m-0 font-weight-bold text-primary"><?php echo e(__('Edit Campaign Form')); ?></h6>
            </div>
            <div class="card-body">

                <form action="<?php echo e(route('admin.campaign.update',$data->id)); ?>" enctype="multipart/form-data" method="POST">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PUT'); ?>
                    <div class="col-md-12 ShowImage mb-3  text-center">
                        <img src="<?php echo e(getPhoto($data->photo)); ?>" class="img-fluid" alt="image" width="400">
                    </div>

                    <div class="row">
                        <div class="col-md-6 ">
                            <div class="form-group">
                                <label for="categorys"><?php echo e(__('Category')); ?></label>
                                <select class="form-control  mb-3" id="categorys" name="category_id" required>
                                    <option value="" selected disabled><?php echo e(__('Select Category')); ?></option>
                                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($item->id); ?>" <?php echo e($data->category_id == $item->id ? 'selected' :
                                        ''); ?>><?php echo e($item->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label for="image"><?php echo e(__('Feature Photo')); ?></label>
                                <span class="ml-3"><?php echo e(__('(Extension:jpeg,jpg,png)')); ?></span>
                                <div class="custom-file">
                                    <input type="file" class="custom-file-input" name="photo" id="image"
                                        accept="image/*">
                                    <label class="custom-file-label" for="photo"><?php echo e(__('Choose file')); ?></label>
                                </div>
                            </div>
                        </div>
                    </div>


                    <div class="form-group">
                        <label for="title"><?php echo e(__('Campaign Title')); ?></label>
                        <input type="text" class="form-control" name="title" id="title" required
                            placeholder="<?php echo e(__('Campaign Title')); ?>" value="<?php echo e(old('title',$data->title)); ?>">
                    </div>

                    <div class="form-group">
                        <label for="location"><?php echo e(__('Location')); ?></label>
                        <input type="text" class="form-control" name="location" id="location" required
                            placeholder="<?php echo e(__('Location')); ?>" value="<?php echo e(old('location',$data->location)); ?>">
                    </div>

                    <div class="form-group">
                        <label for="benefits"><?php echo e(__('People Benefits')); ?></label>
                        <input type="number" class="form-control" name="benefits" id="benefits" required
                            placeholder="<?php echo e(__('People Benefits')); ?>" value="<?php echo e(old('benefits',$data->benefits)); ?>">
                    </div>

                    <div class="form-group">
                        <label for="goal"><?php echo e(__('Goal Amount')); ?></label>
                        <input type="number" step="any" class="form-control" name="goal" id="goal" required
                            placeholder="<?php echo e(__('Goal Amount')); ?>" value="<?php echo e(old('goal',$data->goal)); ?>">
                    </div>


                    <div class="form-group">
                        <label for="end_date"><?php echo e(__('End Date')); ?></label>
                        <input type="date" class="form-control" name="end_date" id="end_date" required
                            placeholder="<?php echo e(__('End Date')); ?>" value="<?php echo e(old('end_date',$data->end_date)); ?>">
                    </div>

                    <div class="form-group">
                        <label for="video_link"><?php echo e(__('Youtube Video ID')); ?></label>
                        <input type="text" step="any" class="form-control" name="video_link" id="video_link"
                            placeholder="<?php echo e(__('Youtube Video ID')); ?>"
                            value="<?php echo e(old('video_link',$data->video_link)); ?>">
                    </div>


                    <div class="form-group">
                        <label for="description"><?php echo e(__('Description')); ?></label>
                        <textarea id="area1" class="form-control summernote" name="description"
                            placeholder="<?php echo e(__('Description')); ?>"
                            required><?php echo e(old('description',$data->description)); ?></textarea>
                    </div>



                    <h6 class="mb-4 mt-0  font-weight-bold text-primary">
                        <?php echo e(__('Campaign Gallery')); ?>

                    </h6>



                    <div class="form-group">
                        <label for="image"><?php echo e(__('Gallery Photo')); ?></label>
                        <span class="ml-3"><?php echo e(__('(Extension:jpeg,jpg,png)')); ?></span>
                        <div class="custom-file">
                            <input type="file" class="custom-file-input" multiple id="upload_gallery_image"
                                name="gallery[]" id="image" accept="image/*">
                            <label class="custom-file-label" for="photo"><?php echo e(__('Choose file')); ?></label>
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="form-label"><?php echo app('translator')->get('Gallery Image'); ?></label>
                        <div class="row gutters-sm" id="view_gallery_images">
                            <?php if($data->galleries->count() > 0): ?>
                            <?php $__currentLoopData = $data->galleries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gallery): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="col-6 col-sm-4 my-3">
                                <figure class="imagecheck-figure gelllabsoluteposition-relative">
                                    <span class="badge badge-danger gelllabsolute removeGalleryPermanent"
                                        data-href="<?php echo e(route('admin.campaign.gallery.remove',$gallery->id)); ?>"> <i
                                            class="fas fa-times"></i></span>
                                    <img src="<?php echo e(getPhoto($gallery->photo)); ?>" alt="}" class="imagecheck-image">
                                </figure>
                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            <?php endif; ?>
                        </div>
                    </div>



                    <div class="form-group">
                        <label class="mt-2">
                            <input type="checkbox" name="is_faq" class="custom-switch-input" <?php echo e($data->is_faq == 1 ?
                            'checked' : ''); ?> id="campaign_faq_checkbox">
                            <span class="custom-switch-indicator"></span>
                            <span class="custom-switch-description"><?php echo app('translator')->get('Add Faq'); ?></span>
                        </label>
                    </div>


                    <div class="<?php echo e($data->is_faq == 1 ? '' : 'd-none'); ?> faq_form_view">

                        <h6 class="mb-4 mt-0 mx-3 font-weight-bold text-primary"><?php echo e(__('Campaign Faq Form')); ?>

                            <button type="button" class="btn btn-success btn-sm add_more_btn"><i
                                    class="fas fa-plus"></i></button>
                        </h6>

                        <div id="showing_faq_form" faq-title="<?php echo e(__('Faq Title')); ?>"
                            faq-content="<?php echo e(__('Faq Content')); ?>">

                            <?php if($data->faqs->count() > 0): ?>
                            <?php $__currentLoopData = $data->faqs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $faq): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                            <div class="row d-flex justify-content-center align-items-center">
                                <div class="col-md-4 col-sm-12">
                                    <div class="form-group">
                                        <label for="faq_title"><?php echo e(__('Faq Title')); ?></label>
                                        <input type="text" class="form-control" name="faq_title[]" id="faq_title"
                                            required placeholder="<?php echo e(__('Faq Title')); ?>" value="<?php echo e($faq->title); ?>">
                                    </div>
                                </div>
                                <div class="col-md-6 col-sm-12">
                                    <div class="form-group">
                                        <label for="faq_content"><?php echo e(__('Faq Content')); ?></label>
                                        <textarea type="number" step="any" class="form-control" name="faq_content[]"
                                            id="faq_content"
                                            placeholder="<?php echo e(__('Faq Content')); ?>"><?php echo e($faq->content); ?></textarea>
                                    </div>
                                </div>
                                <div class="col-md-2 col-sm-12">
                                    <div class="">
                                        <button type="button" class="btn btn-danger btn-sm remove_faq"><i
                                                class="fas fa-minus"></i></button>
                                    </div>
                                </div>
                            </div>

                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                        </div>

                    </div>



                    <div class="form-group">
                        <label class="mt-2">
                            <input type="checkbox" name="is_preloaded" <?php echo e($data->is_preloaded == 1 ? 'checked' : ''); ?>

                            class="custom-switch-input" id="allow_preloaded">
                            <span class="custom-switch-indicator"></span>
                            <span class="custom-switch-description"><?php echo app('translator')->get('Allow Preloaded Amount'); ?></span>
                        </label>
                    </div>


                    <div class="form-group">
                        <label><?php echo e(__('Status')); ?></label>
                        <select class="form-control  mb-3" name="status" required>
                            <option value="1" <?php echo e($data->status == 1 ? 'selected' : ''); ?>><?php echo e(__('Active')); ?></option>
                            <option value="0" <?php echo e($data->status == 0 ? 'selected' : ''); ?>><?php echo e(__('Inactive')); ?></option>
                        </select>
                    </div>


                    <button type="submit" class="btn btn-primary"><?php echo e(__('Submit')); ?></button>
                </form>
            </div>
        </div>
        <!-- Form Sizing -->
        <!-- Horizontal Form -->
    </div>
</div>
<!--Row-->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\charity\backend\project\resources\views/admin/campaign/edit.blade.php ENDPATH**/ ?>