
<?php $__env->startSection('title'); ?>
    <?php echo app('translator')->get('Update Contact Setting'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('breadcrumb'); ?>
    <section class="section">
        <div class="section-header d-flex justify-content-between">
            <h1><?php echo app('translator')->get('Update Contact Setting'); ?></h1>
        </div>
    </section>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="row justify-content-center">
        <div class="col-md-12">
            <div class="card mb-4">
                <div class="card-body">

                    <form action="<?php echo e(route('admin.contact.setting.update')); ?>" method="POST" enctype="multipart/form-data">
                        <?php echo method_field('PUT'); ?>
                        <?php echo csrf_field(); ?>

                        <div class="form-group">
                            <label><?php echo app('translator')->get('Contact Page Title'); ?></label>
                            <input class="form-control" type="text" name="title" value="<?php echo e($contact->title); ?>">
                        </div>

                  

                        <div class="row">
                            <div class="col-lg-6 col-md-6 col-sm-12">
                                <div class="form-group">
                                    <label><?php echo app('translator')->get('Email 1'); ?></label>
                                    <input class="form-control" type="text" name="email1" value="<?php echo e($contact->email1); ?>">
                                </div>
                            </div>

                            <div class="col-lg-6 col-md-6 col-sm-12">
                                <div class="form-group">
                                    <label><?php echo app('translator')->get('Email 2'); ?></label>
                                    <input class="form-control" type="text" name="email2" value="<?php echo e($contact->email2); ?>">
                                </div>
                            </div>
                        </div>

                        <div class="row">
                           <div class="col-lg-6 col-md-6 col-sm-12">
                            <div class="form-group">
                                <label><?php echo app('translator')->get('Phone 1'); ?></label>
                                <input class="form-control" type="text" name="phone1" value="<?php echo e($contact->phone1); ?>">
                            </div>
                           </div>

                            <div class="col-lg-6 col-md-6 col-sm-12">
                                <div class="form-group">
                                    <label><?php echo app('translator')->get('Phone 2'); ?></label>
                                    <input class="form-control" type="text" name="phone2" value="<?php echo e($contact->phone2); ?>">
                                </div>
                            </div>
                        </div>

                        <div class="form-group">
                            <label><?php echo app('translator')->get('Address'); ?></label>
                            <input class="form-control" type="text" name="address" value="<?php echo e($contact->address); ?>">
                        </div>

                        <div class="form-group">
                            <label><?php echo app('translator')->get('Map Iframe Link'); ?></label>
                            <textarea name="map_link" class="form-control" rows="4"><?php echo e($contact->map_link); ?></textarea>
                        </div>


                        <button type="submit" class="btn btn-primary"><?php echo e(__('Submit')); ?></button>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <!--Row-->
<?php $__env->stopSection(); ?>

<?php $__env->startPush('script'); ?>
    <script>
        'use strict';
        $.uploadPreview({
            input_field: "#image-upload", // Default: .image-upload
            preview_box: "#image-preview", // Default: .image-preview
            label_field: "#image-label", // Default: .image-label
            label_default: "<?php echo e(__('Choose File')); ?>", // Default: Choose File
            label_selected: "<?php echo e(__('Update Image')); ?>", // Default: Change File
            no_label: false, // Default: false
            success_callback: null // Default: null
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\car-service\project\resources\views/admin/contact/index.blade.php ENDPATH**/ ?>