

<?php $__env->startSection('title'); ?>
<?php echo app('translator')->get('Categories'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('breadcrumb'); ?>
<section class="section">
   <div class="section-header">
      <h1><?php echo app('translator')->get('Categories'); ?></h1>
   </div>
</section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>


<div class="row">
   <div class="col-lg-12">
      <div class="card mb-4">
         <div class="card-header d-flex justify-content-end">
            <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#add">
               <i class="fas fa-plus"></i> <?php echo app('translator')->get('Add New'); ?>
            </button>

         </div>
         <div class="table-responsive p-3">
            <table class="table table-striped">
               <tr>
                  <th><?php echo app('translator')->get('Photo'); ?></th>
                  <th><?php echo app('translator')->get('Name'); ?></th>
                  <th><?php echo app('translator')->get('Status'); ?></th>
                  <th class="text-right"><?php echo app('translator')->get('Action'); ?></th>
               </tr>
               <?php $__empty_1 = true; $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
               <tr>

                  <td data-label="<?php echo app('translator')->get('Photo'); ?>">
                     <img src="<?php echo e(getPhoto($item->photo)); ?>" class="img-fluid" style="width: 50px" alt="">
                  </td>
                  <td data-label="<?php echo app('translator')->get('Name'); ?>">
                     <?php echo e($item->name); ?>

                  </td>

                  <td data-label="<?php echo app('translator')->get('Status'); ?>">
                     <?php if($item->status == 1): ?>
                     <span class="badge badge-success"> <?php echo app('translator')->get('Active'); ?> </span>
                     <?php else: ?>
                     <span class="badge badge-warning"> <?php echo app('translator')->get('Inactive'); ?> </span>
                     <?php endif; ?>
                  </td>
                  <td data-label="<?php echo app('translator')->get('Action'); ?>" class="text-right">
                     <a href="javascript:void()" class="btn btn-primary approve btn-sm edit mb-1"
                        data-route="<?php echo e(route('admin.category.update',$item->id)); ?>" data-path="<?php echo e(adminpath()); ?>"
                        data-item="<?php echo e($item); ?>" data-toggle="tooltip" title="<?php echo app('translator')->get('Edit'); ?>"><i
                           class="fas fa-edit"></i></a>
                     <a href="javascript:void(0)" class="btn btn-danger btn-sm remove mb-1" data-id="<?php echo e($item->id); ?>"
                        data-toggle="tooltip" title="<?php echo app('translator')->get('Remove'); ?>"><i class="fas fa-trash"></i></a>
                  </td>
               </tr>
               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

               <tr>
                  <td class="text-center" colspan="100%"><?php echo app('translator')->get('No Data Found'); ?></td>
               </tr>

               <?php endif; ?>
            </table>
         </div>
      </div>
   </div>
</div>

<!-- Modal -->
<div class="modal fade" id="add" tabindex="-1" role="dialog" aria-hidden="true">
   <div class="modal-dialog" role="document">
      <form action="<?php echo e(route('admin.category.store')); ?>" method="POST" enctype="multipart/form-data">
         <?php echo csrf_field(); ?>
         <div class="modal-content">
            <div class="modal-header">
               <h5 class="modal-title"><?php echo app('translator')->get('Add new category'); ?></h5>
               <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                  <span aria-hidden="true">&times;</span>
               </button>
            </div>
            <div class="modal-body">
               <div class="form-group">
                  <label><?php echo app('translator')->get('Feature Photo'); ?></label>
                  <div class="form-group d-flex justify-content-center">
                     <div id="image-preview" class="image-preview image-preview_alt" style="">
                        <label for="image-upload" id="image-label"><?php echo app('translator')->get('Choose File'); ?></label>
                        <input type="file" name="photo" id="image-upload" />
                     </div>
                  </div>
               </div>
               <div class="form-group">
                  <label><?php echo app('translator')->get('Name'); ?></label>
                  <input class="form-control" type="text" name="name">
               </div>
               <div class="form-group">
                  <label><?php echo app('translator')->get('Status'); ?></label>
                  <select name="status" class="form-control">
                     <option value="1"><?php echo app('translator')->get('Active'); ?></option>
                     <option value="0"><?php echo app('translator')->get('Inactive'); ?></option>
                  </select>
               </div>
            </div>
            <div class="modal-footer">
               <button type="button" class="btn btn-dark" data-dismiss="modal"><?php echo app('translator')->get('Close'); ?></button>
               <button type="submit" class="btn btn-primary"><?php echo app('translator')->get('Submit'); ?></button>
            </div>
         </div>
      </form>
   </div>
</div>

<div class="modal fade" id="edit" tabindex="-1" role="dialog" aria-hidden="true">
   <div class="modal-dialog" role="document">
      <form action="" method="POST" enctype="multipart/form-data">
         <?php echo csrf_field(); ?>
         <?php echo method_field('PUT'); ?>
         <div class="modal-content">
            <div class="modal-header">
               <h5 class="modal-title"><?php echo app('translator')->get('Edit category'); ?></h5>
               <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                  <span aria-hidden="true">&times;</span>
               </button>
            </div>
            <div class="modal-body">
               <div class="form-group">
                  <label><?php echo app('translator')->get('Feature Photo'); ?></label>
                  <div class="form-group d-flex justify-content-center">
                      <div id="image-preview1" class="image-preview image-preview_alt" style="">
                          <label for="image-upload1" id="image-label1"><?php echo app('translator')->get('Choose File'); ?></label>
                          <input type="file" name="photo" id="image-upload1" />
                      </div>
                  </div>
              </div>
               <div class="form-group">
                  <label><?php echo app('translator')->get('Name'); ?></label>
                  <input class="form-control" type="text" name="name">
               </div>
               <div class="form-group">
                  <label><?php echo app('translator')->get('Status'); ?></label>
                  <select name="status" class="form-control">
                     <option value="1"><?php echo app('translator')->get('Active'); ?></option>
                     <option value="0"><?php echo app('translator')->get('Inactive'); ?></option>
                  </select>
               </div>
            </div>
            <div class="modal-footer">
               <button type="button" class="btn btn-dark" data-dismiss="modal"><?php echo app('translator')->get('Close'); ?></button>
               <button type="submit" class="btn btn-primary"><?php echo app('translator')->get('Submit'); ?></button>
            </div>
         </div>
      </form>
   </div>
</div>


<!-- Modal -->
<div class="modal fade" id="removeMod" tabindex="-1" role="dialog">
   <div class="modal-dialog" role="document">
      <form action="<?php echo e(route('admin.category.destroy')); ?>" method="POST">
         <?php echo method_field('DELETE'); ?>
         <?php echo csrf_field(); ?>
         <input type="hidden" name="id">
         <div class="modal-content">
            <div class="modal-body">
               <h5><?php echo app('translator')->get('Are you sure to remove?'); ?></h5>
            </div>
            <div class="modal-footer">
               <button type="button" class="btn btn-dark" data-dismiss="modal"><?php echo app('translator')->get('Close'); ?></button>
               <button type="submit" class="btn btn-danger"><?php echo app('translator')->get('Confirm'); ?></button>
            </div>
         </div>
      </form>
   </div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('script'); ?>
<script>
   'use strict';

   $.uploadPreview({
            input_field: "#image-upload",
            preview_box: "#image-preview",
            label_field: "#image-label",
            label_default: "<?php echo e(__('Choose File')); ?>",
            label_selected: "<?php echo e(__('Update Image')); ?>",
            no_label: false,
            success_callback: null
        });
        $.uploadPreview({
            input_field: "#image-upload1",
            preview_box: "#image-preview1",
            label_field: "#image-label1",
            label_default: "<?php echo e(__('Choose File')); ?>",
            label_selected: "<?php echo e(__('Update Image')); ?>",
            no_label: false,
            success_callback: null
        });

       $('.edit').on('click',function () { 
          var data = $(this).data('item');
          $('#edit').find('input[name=name]').val(data.name);
         $('#edit').find('select[name=status]').val(data.status);
            $('#edit').find('form').attr('action',$(this).data('route'));
            let path = $(this).attr('data-path');
            $('#edit').find('#image-preview1').css('background-image', `url('${path}/${data.photo}')`);
             $('#edit').modal('show');
       })

       $('.remove').on('click',function () { 
         $('#removeMod').find('input[name=id]').val($(this).data('id'))
         $('#removeMod').modal('show')
       })
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\charity\backend\project\resources\views/admin/category/index.blade.php ENDPATH**/ ?>