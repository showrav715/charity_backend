
<?php $__env->startSection('title'); ?>
    <?php echo app('translator')->get('Admin Dashboard'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('breadcrumb'); ?>
    <section class="section">
        <div class="section-header">
            <h1><?php echo app('translator')->get('Dashboard'); ?></h1>
        </div>
    </section>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-xl-3 col-lg-3 col-sm-6 col-12">
            <div class="card card-statistic-1">
                <div class="card-icon bg-primary">
                    <i class="fas fa-users"></i>
                </div>
                <div class="card-wrap">
                    <div class="card-header">
                        <h4><?php echo app('translator')->get('Total Contact Messages'); ?></h4>
                    </div>
                    <div class="card-body">
                        <?php echo e($total_getintouchs); ?>

                    </div>
                </div>
            </div>
        </div>
        
        <div class="col-xl-3 col-lg-3 col-sm-6 col-12">
            <div class="card card-statistic-1">
                <div class="card-icon bg-primary">
                    <i class="far fa-user"></i>
                </div>
                <div class="card-wrap">
                    <div class="card-header">
                        <h4><?php echo app('translator')->get('Total Services'); ?></h4>
                    </div>
                    <div class="card-body">
                        <?php echo e($total_services); ?>

                    </div>
                </div>
            </div>
        </div>


        <div class="col-xl-3 col-lg-3 col-sm-6 col-12">
            <div class="card card-statistic-1">
                <div class="card-icon bg-primary">
                    <i class="far fa-user"></i>
                </div>
                <div class="card-wrap">
                    <div class="card-header">
                        <h4><?php echo app('translator')->get('Total Team Members'); ?></h4>
                    </div>
                    <div class="card-body">
                        <?php echo e($total_teams); ?>

                    </div>
                </div>
            </div>
        </div>

        <div class="col-xl-3 col-lg-3 col-sm-6 col-12">
            <div class="card card-statistic-1">
                <div class="card-icon bg-primary">
                    <i class="far fa-user"></i>
                </div>
                <div class="card-wrap">
                    <div class="card-header">
                        <h4><?php echo app('translator')->get('Total Blogs'); ?></h4>
                    </div>
                    <div class="card-body">
                        <?php echo e($total_blogs); ?>

                    </div>
                </div>
            </div>
        </div>


    </div>

    <div class="row">
        <div class="col-12 col-md-12 col-lg-12">
            <div class="card">
                <div class="card-header">
                    <h4><?php echo app('translator')->get('Recent Get in Touch Message'); ?></h4>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-striped">
                            <thead>
                                <tr>
                                <th><?php echo app('translator')->get('Name'); ?></th>
                                <th><?php echo app('translator')->get('Email'); ?></th>
                                <th><?php echo app('translator')->get('Phone'); ?></th>
                                <th><?php echo app('translator')->get('Message'); ?></th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $getintouchs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td data-label="<?php echo app('translator')->get('Name'); ?>">
                                        <?php echo e($item->name); ?>

                                    </td>
                                    <td data-label="<?php echo app('translator')->get('Email'); ?>">
                                        <?php echo e($item->email); ?>

                                    </td>
                                    <td data-label="<?php echo app('translator')->get('Phone'); ?>">
                                        <?php echo e($item->phone); ?>

                                    </td>
                                    
                                    <td data-label="<?php echo app('translator')->get('Message'); ?>">
                                        <?php echo e($item->message); ?>

                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>




    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\car-service\project\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>