
<?php $__env->startSection('title'); ?>
<?php echo app('translator')->get('Edit Cta Section'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('breadcrumb'); ?>
<section class="section">
    <div class="section-header d-flex justify-content-between">
        <h1><?php echo app('translator')->get('Edit Cta Section'); ?></h1>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="row justify-content-center">
    <div class="col-md-12">
        <div class="card mb-4">
            <div class="card-body">

                <form action="<?php echo e(route('admin.gs.update')); ?>" method="POST" enctype="multipart/form-data">
                    <?php echo method_field('post'); ?>
                    <?php echo csrf_field(); ?>

                    <div class="row">

                        <div class="col-8 offset-2 text-center">
                            <label for="">Cta Section Photo</label>
                            <div class="form-group d-flex justify-content-center">
                                <div id="image-preview" class="image-preview image-preview_alt"
                                    style="background-image:url(<?php echo e(getPhoto($gs->cta_photo)); ?>);">
                                    <label for="image-upload" id="image-label"><?php echo app('translator')->get('Choose File'); ?></label>
                                    <input type="file" name="cta_photo" id="image-upload" />
                                </div>
                            </div>
                        </div>
                    </div>

                    <input type="hidden" name="type" value="cta" id="">
                    <div class="form-group">
                        <label><?php echo app('translator')->get('Title'); ?></label>
                        <input class="form-control" type="text" name="cta_title" value="<?php echo e($gs->cta_title); ?>">
                    </div>
                    <div class="form-group">
                        <label><?php echo app('translator')->get('Button Text'); ?></label>
                        <input class="form-control" type="text" name="cta_btn_text" value="<?php echo e($gs->cta_btn_text); ?>">
                    </div>
                    <div class="form-group">
                        <label><?php echo app('translator')->get('Button Url'); ?></label>
                        <input class="form-control" type="text" name="cta_btn_url" value="<?php echo e($gs->cta_btn_url); ?>">
                    </div>


                    <button type="submit" class="btn btn-primary"><?php echo e(__('Update')); ?></button>
                </form>
            </div>
        </div>
    </div>
</div>
<!--Row-->
<?php $__env->stopSection(); ?>

<?php $__env->startPush('script'); ?>
<script>
    'use strict';
        $.uploadPreview({
            input_field: "#image-upload", // Default: .image-upload
            preview_box: "#image-preview", // Default: .image-preview
            label_field: "#image-label", // Default: .image-label
            label_default: "<?php echo e(__('Choose File')); ?>", // Default: Choose File
            label_selected: "<?php echo e(__('Update Image')); ?>", // Default: Change File
            no_label: false, // Default: false
            success_callback: null // Default: null
        });
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\charity\backend\project\resources\views/admin/generalsetting/cta_section.blade.php ENDPATH**/ ?>