

<?php $__env->startSection('title'); ?>
    <?php echo app('translator')->get('General Settings'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('breadcrumb'); ?>
    <section class="section">
        <div class="section-header">
            <h1><?php echo app('translator')->get('Site Settings'); ?></h1>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="row justify-content-center">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">
                    <h4><?php echo app('translator')->get('Basic Settings'); ?></h4>
                </div>
                <div class="card-body">
                    <form action="<?php echo e(route('admin.gs.update')); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" name="basic" value="1">

                        <div class="form-group">
                            <label for="frontend_url" class="col-form-label"><?php echo e(__('Frontend Url')); ?></label>
                            <input type="text" class="form-control" id="frontend_url" name="frontend_url"
                                placeholder="<?php echo e(__('Frontend Url')); ?>" value="<?php echo e($gs->frontend_url); ?>">
                        </div>

                        <div class="form-group">
                            <label for="title" class="col-form-label"><?php echo e(__('Website Title')); ?></label>
                            <input type="text" class="form-control" id="title" name="title"
                                placeholder="<?php echo e(__('Website Title')); ?>" value="<?php echo e($gs->title); ?>">
                        </div>

                        <div class="form-group ">
                            <label for="header_text" class="col-form-label"><?php echo e(__('Header Text')); ?></label>
                            <input type="text" class="form-control" id="header_text" name="header_text"
                                placeholder="<?php echo e(__('Header Text')); ?>" value="<?php echo e($gs->header_text); ?>">
                        </div>
                      
                        <div class="form-group ">
                            <label for="phone" class="col-form-label"><?php echo e(__('Phone')); ?></label>
                            <input type="text" class="form-control" id="phone" name="phone"
                                placeholder="<?php echo e(__('Phone')); ?>" value="<?php echo e($gs->phone); ?>">
                        </div>

                        <div class="form-group ">
                            <label for="email" class="col-form-label"><?php echo e(__('Email')); ?></label>
                            <input type="text" class="form-control" id="email" name="email"
                                placeholder="<?php echo e(__('Email')); ?>" value="<?php echo e($gs->email); ?>">
                        </div>


                        <div class="form-group ">
                            <label for="address" class="col-form-label"><?php echo e(__('Address')); ?></label>
                            <input type="text" class="form-control" id="address" name="address"
                                placeholder="<?php echo e(__('Address')); ?>" value="<?php echo e($gs->address); ?>">
                        </div>

                        <div class="form-group ">
                            <label for="footer_text" class="col-form-label"><?php echo e(__('Footer Text')); ?></label>
                            <input type="text" class="form-control" id="footer_text" name="footer_text"
                                placeholder="<?php echo e(__('Footer Text')); ?>" value="<?php echo e($gs->footer_text); ?>">
                        </div>

                        <div class="form-group ">
                            <label for="copyright_text" class="col-form-label"><?php echo e(__('Copyright Text')); ?></label>
                            <input type="text" class="form-control" id="copyright_text" name="copyright_text"
                                placeholder="<?php echo e(__('Copyright Text')); ?>" value="<?php echo e($gs->copyright_text); ?>">
                        </div>

                        <div class="form-group text-right">
                            <button class="btn btn-primary"><?php echo app('translator')->get('Update'); ?></button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('script'); ?>
    <script src="<?php echo e(asset('assets/admin/js/colorpicker.js')); ?>"></script>
    <script>
        'use strict';
        $(document).ready(function() {
            $(".cp").colorpicker({
                format: "auto",
            });

            $('input[name=allowed_email]').tagify();

            $('#select2-basic').select2();
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\charity-new\project\resources\views/admin/generalsetting/settings.blade.php ENDPATH**/ ?>