
<?php $__env->startSection('title'); ?>
<?php echo app('translator')->get('Add New Volunteer'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('breadcrumb'); ?>
<section class="section">
    <div class="section-header  d-flex justify-content-between">
        <h1><?php echo app('translator')->get('Add New Volunteer'); ?></h1>
        <a href="<?php echo e(route('admin.volunteer.index')); ?>" class="btn btn-primary"><i class="fas fa-backward"></i>
            <?php echo app('translator')->get('Back'); ?></a>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

<div class="row justify-content-center">
    <div class="col-md-12">
        <!-- Form Basic -->
        <div class="card mb-4">
            <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                <h6 class="m-0 font-weight-bold text-primary"><?php echo e(__('Add New Volunteer Form')); ?></h6>
            </div>
            <div class="card-body">

                <form action="<?php echo e(route('admin.volunteer.store')); ?>" enctype="multipart/form-data" method="POST">
                    <?php echo csrf_field(); ?>
                    <div class="form-group d-flex justify-content-center">
                        <div id="image-preview" class="image-preview image-preview_alt"
                            style="background-image:url(<?php echo e(getPhoto('')); ?>);">
                            <label for="image-upload" id="image-label"><?php echo app('translator')->get('Choose File'); ?></label>
                            <input type="file" name="photo" id="image-upload" />
                        </div>
                    </div>

                    <div class="form-group">
                        <label for="name"><?php echo e(__('Name')); ?></label>
                        <input type="text" class="form-control" name="name" id="name" required
                            placeholder="<?php echo e(__('Name')); ?>" value="<?php echo e(old('name')); ?>">
                    </div>

                    <div class="form-group">
                        <label for="designation"><?php echo e(__('Designation')); ?></label>
                        <input type="text" class="form-control" name="designation" id="designation" required
                            placeholder="<?php echo e(__('Designation')); ?>" value="<?php echo e(old('designation')); ?>">
                    </div>

                    <div class="row">
                        <div class="col-md-6">
                            <div class="form-group">
                                <label for="facebook"><?php echo e(__('Facebook Link')); ?></label>
                                <input type="text" class="form-control" name="facebook" id="facebook" 
                                    placeholder="<?php echo e(__('Facebook')); ?>" value="<?php echo e(old('facebook')); ?>">
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label for="instragram"><?php echo e(__('Instragram Link')); ?></label>
                                <input type="text" class="form-control" name="instragram" id="instragram" 
                                    placeholder="<?php echo e(__('Instragram')); ?>" value="<?php echo e(old('instragram')); ?>">
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label for="twitter"><?php echo e(__('Twitter Link')); ?></label>
                                <input type="text" class="form-control" name="twitter" id="twitter" 
                                    placeholder="<?php echo e(__('Twitter')); ?>" value="<?php echo e(old('twitter')); ?>">
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label for="linkedin"><?php echo e(__('Linkedin')); ?></label>
                                <input type="text" class="form-control" name="linkedin" id="linkedin" 
                                    placeholder="<?php echo e(__('Linkedin')); ?>" value="<?php echo e(old('linkedin')); ?>">
                            </div>
                        </div>
                    </div>

                    <button type="submit" class="btn btn-primary"><?php echo e(__('Submit')); ?></button>
                </form>
            </div>
        </div>
        <!-- Form Sizing -->
        <!-- Horizontal Form -->
    </div>
</div>
<!--Row-->
<?php $__env->stopSection(); ?>

<?php $__env->startPush('script'); ?>
<script>
    'use strict';

    $.uploadPreview({
                input_field: "#image-upload", // Default: .image-upload
                preview_box: "#image-preview", // Default: .image-preview
                label_field: "#image-label", // Default: .image-label
                label_default: "<?php echo e(__('Choose File')); ?>", // Default: Choose File
                label_selected: "<?php echo e(__('Update Image')); ?>", // Default: Change File
                no_label: false, // Default: false
                success_callback: null // Default: null
            });
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\charity\backend\project\resources\views/admin/volunteer/create.blade.php ENDPATH**/ ?>