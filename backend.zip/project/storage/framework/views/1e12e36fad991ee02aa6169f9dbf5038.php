<aside id="sidebar-wrapper">
        <ul class="sidebar-menu mb-5">
                <li class="menu-header"><?php echo app('translator')->get('Dashboard'); ?></li>
                <li class="nav-item <?php echo e(menu('admin.dashboard')); ?>">
                        <a href="<?php echo e(route('admin.dashboard')); ?>" class="nav-link"><i
                                        class="fas fa-fire"></i><span><?php echo app('translator')->get('Dashboard'); ?></span></a>
                </li>

                <li class="nav-item dropdown <?php echo e(menu(['admin.contact*'])); ?>">
                        <a href="#" class="nav-link has-dropdown" data-toggle="dropdown"><i
                                        class="fas fa-envelope-open-text"></i></i>
                                <span><?php echo app('translator')->get('Manage Campaigns'); ?></span></a>
                        <ul class="dropdown-menu">

                                <li class="<?php echo e(menu('admin.contact.message')); ?>"><a class="nav-link"
                                                href="<?php echo e(route('admin.category.index')); ?>"><?php echo app('translator')->get('Categories'); ?></a>
                                </li>
                                <li class="<?php echo e(menu('admin.contact.message')); ?>"><a class="nav-link"
                                                href="<?php echo e(route('admin.preloaded.index')); ?>"><?php echo app('translator')->get('Preloaded
                                                Amount'); ?></a>
                                </li>
                                <li class="<?php echo e(menu('admin.campaign.index')); ?>"><a class="nav-link"
                                                href="<?php echo e(route('admin.campaign.index')); ?>"><?php echo app('translator')->get('Manage Campaigns'); ?></a>
                                </li>
                        </ul>
                </li>
                <li class="nav-item dropdown <?php echo e(menu(['admin.contact*'])); ?>">
                        <a href="#" class="nav-link has-dropdown" data-toggle="dropdown"><i
                                        class="fas fa-envelope-open-text"></i></i>
                                <span><?php echo app('translator')->get('Manage Contact'); ?></span></a>
                        <ul class="dropdown-menu">

                                <li class="<?php echo e(menu('admin.contact.message')); ?>"><a class="nav-link"
                                                href="<?php echo e(route('admin.contact.message')); ?>"><?php echo app('translator')->get('Contact
                                                Messages'); ?></a>
                                </li>
                                <li class="<?php echo e(menu('admin.contact.setting.index')); ?>"><a class="nav-link"
                                                href="<?php echo e(route('admin.contact.setting.index')); ?>"><?php echo app('translator')->get('Contact
                                                Setting'); ?></a></li>
                        </ul>
                </li>


                <li class="nav-item dropdown <?php echo e(menu(['admin.gateway*'])); ?>">
                        <a href="#" class="nav-link has-dropdown" data-toggle="dropdown"><i
                                        class="fas fa-money-check-alt"></i> <span><?php echo app('translator')->get('Payment Gateway'); ?></span></a>
                        <ul class="dropdown-menu">
                                <li class="<?php echo e(menu('admin.currency.index')); ?>"><a class="nav-link"
                                                href="<?php echo e(route('admin.currency.index')); ?>"><?php echo app('translator')->get('Currency'); ?></a></li>
                                <li class="<?php echo e(menu('admin.gateway')); ?>"><a class="nav-link"
                                                href="<?php echo e(route('admin.gateway')); ?>"><?php echo app('translator')->get('Gateways'); ?></a>
                                </li>
                        </ul>
                </li>




                <li class="nav-item dropdown <?php echo e(menu(['admin.bcategory*','admin.blog*'])); ?>">
                        <a href="#" class="nav-link has-dropdown" data-toggle="dropdown"><i
                                        class="fab fa-blogger-b"></i>
                                <span><?php echo app('translator')->get('Blogs'); ?></span></a>
                        <ul class="dropdown-menu">
                                <li class="<?php echo e(menu('admin.bcategory.index')); ?>"><a class="nav-link"
                                                href="<?php echo e(route('admin.bcategory.index')); ?>"><?php echo app('translator')->get('Category'); ?></a></li>
                                <li class="<?php echo e(menu('admin.blog.index')); ?>"><a class="nav-link"
                                                href="<?php echo e(route('admin.blog.index')); ?>"><?php echo app('translator')->get('Blogs'); ?></a>
                                </li>
                                <li class="<?php echo e(menu('admin.blog.comment')); ?>"><a class="nav-link"
                                                href="<?php echo e(route('admin.blog.comment')); ?>"><?php echo app('translator')->get('Comments'); ?></a>
                                </li>
                        </ul>
                </li>

                <li class="nav-item dropdown <?php echo e(menu(['admin.page*'])); ?>">
                        <a href="#" class="nav-link has-dropdown" data-toggle="dropdown"><i class="fas fa-file-alt"></i>
                                <span><?php echo app('translator')->get('Manage Pages'); ?></span></a>
                        <ul class="dropdown-menu">
                                <li class="<?php echo e(menu('admin.about.index')); ?>"><a class="nav-link"
                                        href="<?php echo e(route('admin.counter.index')); ?>"><?php echo app('translator')->get('About Counter'); ?></a></li>
                                        <li class="<?php echo e(menu('admin.counter.index')); ?>"><a class="nav-link"
                                                href="<?php echo e(route('admin.about.index')); ?>"><?php echo app('translator')->get('About Page'); ?></a></li>
                                <li class="<?php echo e(menu('admin.gateway')); ?>"><a class="nav-link"
                                                href="<?php echo e(route('admin.page.index')); ?>"><?php echo app('translator')->get('Other Page'); ?></a>
                                </li>
                        </ul>
                </li>


                <li class="nav-item <?php echo e(menu('admin.volunteer.index')); ?>">
                        <a href="<?php echo e(route('admin.volunteer.index')); ?>" class="nav-link">
                                <i class="fas fa-users-cog"></i>
                                <span><?php echo app('translator')->get('Manage Volunteer'); ?></span>
                        </a>
                </li>

                <li class="menu-header"><?php echo app('translator')->get('General'); ?></li>

                <li
                        class="nav-item dropdown <?php echo e(menu(['admin.gs*','admin.social.manage*','admin.language*', 'admin.cookie'])); ?>">
                        <a href="#" class="nav-link has-dropdown" data-toggle="dropdown"><i
                                        class="fas fa-cog"></i><span><?php echo app('translator')->get('General Settings'); ?></span></a>
                        <ul class="dropdown-menu">

                                <li class="<?php echo e(menu('admin.gs.site.settings')); ?>"><a class="nav-link"
                                                href="<?php echo e(route('admin.gs.site.settings')); ?>"><?php echo app('translator')->get('Site Settings'); ?></a>
                                </li>
                                <li class="<?php echo e(menu('admin.gs.logo')); ?>"><a class="nav-link"
                                                href="<?php echo e(route('admin.gs.logo')); ?>"><?php echo app('translator')->get('Logo'); ?></a></li>
                                <li class="<?php echo e(menu('admin.gs.breadcumb')); ?>"><a class="nav-link"
                                                href="<?php echo e(route('admin.gs.breadcumb')); ?>"><?php echo app('translator')->get('Breadcumb'); ?></a></li>
                                <li class="<?php echo e(menu('admin.language')); ?>"><a class="nav-link"
                                                href="<?php echo e(route('admin.language')); ?>"><?php echo app('translator')->get('Language'); ?></a></li>

                                <li class="<?php echo e(menu('admin.gs.maintainance.settings')); ?>"><a class="nav-link"
                                                href="<?php echo e(route('admin.gs.maintainance.settings')); ?>"><?php echo app('translator')->get('Maintenance'); ?></a>
                                </li>
                        </ul>
                </li>



                <li
                        class="nav-item dropdown <?php echo e(menu(['admin.front*','admin.faq*','admin.testimonial*','admin.brand*','admin.contact.section','admin.slider*','admin.counter*', 'admin.frontend*'])); ?>">
                        <a href="#" class="nav-link has-dropdown"><i class="fas fa-th"></i>
                                <span><?php echo app('translator')->get('Frontend Setting'); ?></span></a>
                        <ul class="dropdown-menu">

                                <li class="<?php echo e(menu('admin.hero.index')); ?>"><a class="nav-link"
                                                href="<?php echo e(route('admin.hero.index')); ?>"><?php echo app('translator')->get('Hero Section'); ?></a></li>
                                <li class="<?php echo e(menu('admin.about.index')); ?>"><a class="nav-link"
                                                href="<?php echo e(route('admin.about.index')); ?>"><?php echo app('translator')->get('About'); ?></a></li>

                                <li class="<?php echo e(menu('admin.testimonial.index')); ?>"><a class="nav-link"
                                                href="<?php echo e(route('admin.testimonial.index')); ?>"><?php echo app('translator')->get('Testimonials'); ?></a>
                                </li>

                                <li class="<?php echo e(menu('admin.testimonial.index')); ?>"><a class="nav-link"
                                                href="<?php echo e(route('admin.cta.index')); ?>"><?php echo app('translator')->get('CTA Section'); ?></a>
                                </li>

                                <li class="<?php echo e(menu('admin.home.sections')); ?>"><a class="nav-link"
                                                href="<?php echo e(route('admin.home.sections')); ?>"><?php echo app('translator')->get('Home Page Sections
                                                '); ?></a>
                                </li>

                        </ul>
                </li>

                <li class="menu-header"><?php echo app('translator')->get('Staff and Role'); ?></li>
                <li class="nav-item <?php echo e(menu('admin.role*')); ?>">
                        <a href="<?php echo e(route('admin.role.index')); ?>" class="nav-link"><i
                                        class="far fa-question-circle"></i><span><?php echo app('translator')->get('Manage Role'); ?></span></a>
                </li>


                <li class="nav-item <?php echo e(menu('admin.staff*')); ?>">
                        <a href="<?php echo e(route('admin.staff.manage')); ?>" class="nav-link"><i
                                        class="fas fa-user-shield"></i><span><?php echo app('translator')->get('Manage Staff'); ?></span></a>
                </li>

                <li class="nav-item <?php echo e(menu('admin.clear.cache')); ?>">
                        <a href="<?php echo e(route('admin.clear.cache')); ?>" class="nav-link"><i class="fas fa-broom"></i>
                                <span><?php echo app('translator')->get('Clear Cache'); ?></span></a>
                </li>
        </ul>
</aside><?php /**PATH C:\xampp\htdocs\charity\backend\project\resources\views/admin/partials/sidebar.blade.php ENDPATH**/ ?>