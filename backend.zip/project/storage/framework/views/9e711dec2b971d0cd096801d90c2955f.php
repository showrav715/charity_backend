

<?php $__env->startSection('title'); ?>
    <?php echo app('translator')->get('Contact Messages'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('breadcrumb'); ?>
    <section class="section">
        <div class="section-header">
            <h1><?php echo app('translator')->get('Contact Messages'); ?></h1>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-lg-12">
            <div class="card mb-4">
                <div class="table-responsive p-3">
                    <table class="table table-striped" id="table">
                        <thead>
                            <tr>

                                <th><?php echo app('translator')->get('Name'); ?></th>
                                <th><?php echo app('translator')->get('Email'); ?></th>
                                <th><?php echo app('translator')->get('Phone'); ?></th>
                                <th><?php echo app('translator')->get('Subject'); ?></th>
                                <th><?php echo app('translator')->get('Message'); ?></th>
                                <th class="text-right"><?php echo app('translator')->get('Action'); ?></th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $messages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>

                                    <td data-label="<?php echo app('translator')->get('Name'); ?>">
                                        <?php echo e($item->name); ?>

                                    </td>
                                    <td data-label="<?php echo app('translator')->get('Email'); ?>">
                                        <?php echo e($item->email); ?>

                                    </td>
                                    <td data-label="<?php echo app('translator')->get('Phone'); ?>">
                                        <?php echo e($item->phone); ?>

                                    </td>
                                    <td data-label="<?php echo app('translator')->get('Subject'); ?>">
                                        <?php echo e($item->subject); ?>

                                    </td>
                                    <td data-label="<?php echo app('translator')->get('Message'); ?>">
                                        <?php echo e($item->message); ?>

                                    </td>
                                    <td data-label="<?php echo app('translator')->get('Action'); ?>" class="text-right">
                                        <a href="javascript:void(0)" class="btn btn-danger btn-sm remove mb-1"
                                            data-id="<?php echo e($item->id); ?>" data-toggle="tooltip"
                                            title="<?php echo app('translator')->get('Remove'); ?>"><i class="fas fa-trash"></i></a>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

 
    <div class="modal fade" id="removeMod" tabindex="-1" role="dialog">
        <div class="modal-dialog" role="document">
            <form action="<?php echo e(route('admin.contact.message.delete')); ?>" method="POST">
                <?php echo method_field('DELETE'); ?>
                <?php echo csrf_field(); ?>
                <input type="hidden" name="id">
                <div class="modal-content">
                    <div class="modal-body">
                        <h5><?php echo app('translator')->get('Are you sure to remove?'); ?></h5>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-dark" data-dismiss="modal"><?php echo app('translator')->get('Close'); ?></button>
                        <button type="submit" class="btn btn-danger"><?php echo app('translator')->get('Confirm'); ?></button>
                    </div>
                </div>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>


<?php $__env->startPush('script'); ?>
    <script>
        'use strict';
        $('.remove').on('click', function() {
            $('#removeMod').find('input[name=id]').val($(this).data('id'))
            $('#removeMod').modal('show')
        })
    </script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\car-service\project\resources\views/admin/contact/messages.blade.php ENDPATH**/ ?>