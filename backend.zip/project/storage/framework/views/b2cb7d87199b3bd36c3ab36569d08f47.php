

<?php $__env->startSection('title'); ?>
<?php echo app('translator')->get('Manage Campaign'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('breadcrumb'); ?>
<section class="section">
    <div class="section-header">
        <h1><?php echo app('translator')->get('Manage Campaign'); ?></h1>
    </div>
</section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-lg-12">
        <div class="card mb-4">
            <div class="card-header d-flex justify-content-end">
                <a href="<?php echo e(route('admin.campaign.create')); ?>" class="btn btn-primary">
                    <i class="fas fa-plus"></i> <?php echo app('translator')->get('Add New'); ?>
                </a>

            </div>
            <div class="table-responsive p-3">
                <table class="table table-striped">
                    <tr>
                        <th><?php echo app('translator')->get('Photo'); ?></th>
                        <th><?php echo app('translator')->get('Title'); ?></th>
                        <th><?php echo app('translator')->get('Goal'); ?></th>
                        <th><?php echo app('translator')->get('Resad'); ?></th>
                        <th><?php echo app('translator')->get('Feature'); ?></th>
                        <th><?php echo app('translator')->get('Status'); ?></th>
                        <th class="text-right"><?php echo app('translator')->get('Action'); ?></th>
                    </tr>
                    <?php $__empty_1 = true; $__currentLoopData = $campaigns; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td data-label="<?php echo app('translator')->get('Photo'); ?>">
                            <img src="<?php echo e(getPhoto($item->photo)); ?>" alt="icon" class="img-fluid" style="width: 150px">
                        </td>
                        <td data-label="<?php echo app('translator')->get('Title'); ?>">
                            <?php echo e($item->title); ?>

                        </td>
                        <td data-label="<?php echo app('translator')->get('Goal'); ?>">
                            <?php echo e(showAdminAmount($item->goal)); ?>

                        </td>
                        <td data-label="<?php echo app('translator')->get('Raised'); ?>">
                            <?php echo e(showAdminAmount($item->raised)); ?>

                        </td>

                        <td data-label="<?php echo app('translator')->get('Feature'); ?>">
                            <div class="btn-group mb-2">
                                <button class="btn btn-<?php echo e($item->is_feature == 1 ? 'success' : 'danger'); ?> btn-sm dropdown-toggle" type="button" data-toggle="dropdown"
                                    aria-haspopup="true" aria-expanded="false">
                                   <?php if($item->is_feature == 1): ?> 
                                   <?php echo app('translator')->get('Yes'); ?>
                                    <?php else: ?>
                                    <?php echo app('translator')->get('No'); ?>
                                    <?php endif; ?>
                                </button>
                                <div class="dropdown-menu" x-placement="bottom-start"
                                    style="position: absolute; transform: translate3d(0px, 29px, 0px); top: 0px; left: 0px; will-change: transform;">
                                    <a class="dropdown-item" href="<?php echo e(route('admin.campaign.status',[$item->id,1])); ?>">Yes</a>
                                    <a class="dropdown-item" href="<?php echo e(route('admin.campaign.status',[$item->id,0])); ?>">No</a>
                                </div>
                            </div>
                        </td>

                        <td data-label="<?php echo app('translator')->get('Status'); ?>">
                            <?php if($item->status == 1): ?>
                            <span class="badge badge-success"> <?php echo app('translator')->get('Active'); ?> </span>
                            <?php else: ?>
                            <span class="badge badge-warning"> <?php echo app('translator')->get('Inactive'); ?> </span>
                            <?php endif; ?>
                        </td>



                        <td data-label="<?php echo app('translator')->get('Action'); ?>" class="text-right">
                            <a href="<?php echo e(route('admin.campaign.edit', $item->id)); ?>"
                                class="btn btn-primary approve btn-sm  mb-1" data-toggle="tooltip"
                                title="<?php echo app('translator')->get('Edit'); ?>"><i class="fas fa-edit"></i></a>
                            <a href="javascript:void(0)" class="btn btn-danger btn-sm remove mb-1"
                                data-id="<?php echo e($item->id); ?>" data-toggle="tooltip" title="<?php echo app('translator')->get('Remove'); ?>"><i
                                    class="fas fa-trash"></i></a>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

                    <tr>
                        <td class="text-center" colspan="100%"><?php echo app('translator')->get('No Data Found'); ?></td>
                    </tr>
                    <?php endif; ?>
                </table>
            </div>
        </div>
    </div>
</div>



<!-- Modal -->
<div class="modal fade" id="removeMod" tabindex="-1" role="dialog">
    <div class="modal-dialog" role="document">
        <form action="<?php echo e(route('admin.campaign.destroy')); ?>" method="POST">
            <?php echo method_field('DELETE'); ?>
            <?php echo csrf_field(); ?>
            <input type="hidden" name="id">
            <div class="modal-content">
                <div class="modal-body">
                    <h5><?php echo app('translator')->get('Are you sure to remove?'); ?></h5>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-dark" data-dismiss="modal"><?php echo app('translator')->get('Close'); ?></button>
                    <button type="submit" class="btn btn-danger"><?php echo app('translator')->get('Confirm'); ?></button>
                </div>
            </div>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('script'); ?>
<script>
    'use strict';
        $('.remove').on('click', function() {
            $('#removeMod').find('input[name=id]').val($(this).data('id'))
            $('#removeMod').modal('show')
        })
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\charity-new\project\resources\views/admin/campaign/index.blade.php ENDPATH**/ ?>