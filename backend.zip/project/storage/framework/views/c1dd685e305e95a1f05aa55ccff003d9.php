

<h1><?php echo app('translator')->get('NOT FOUND'); ?></h1><?php /**PATH C:\xampp\htdocs\car-service\project\resources\views/errors/404.blade.php ENDPATH**/ ?>