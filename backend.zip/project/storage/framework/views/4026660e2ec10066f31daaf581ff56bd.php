
<?php $__env->startSection('breadcrumb'); ?>
<section class="section">
    <div class="section-header">
        <h1><?php echo app('translator')->get('Maintainance Settings'); ?></h1>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('title'); ?>
<?php echo app('translator')->get('Maintainance'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-md-12">
        <div class="card">
            <div class="card-header">
                <h6 class="text-primary"> <?php echo app('translator')->get('Maintainance Settings'); ?></h6>
            </div>
            <div class="card-body">
                <form id="" action="<?php echo e(route('admin.gs.update')); ?>" enctype="multipart/form-data" method="POST">
                    <?php echo csrf_field(); ?>
                    <input type="hidden" name="maintenance" value="1" id="">
                    <div class="selectgroup w-100 mb-5">
                        <label class="selectgroup-item">
                            <input type="radio" <?php echo e($gs->is_maintenance == 1 ? 'checked' : ''); ?> name="is_maintenance"
                            value="1"
                            class="selectgroup-input">
                            <span class="selectgroup-button">Active</span>
                        </label>
                        <label class="selectgroup-item">
                            <input type="radio" <?php echo e($gs->is_maintenance == 0 ? 'checked' : ''); ?> name="is_maintenance"
                            value="0"
                            class="selectgroup-input">
                            <span class="selectgroup-button"><?php echo app('translator')->get('Deactive'); ?></span>
                        </label>
                    </div>
                    <div class="form-group d-flex justify-content-center">
                        <div id="image-preview" class="image-preview image-preview_alt"
                            style="background-image:url(<?php echo e(getPhoto($gs->maintenance_photo)); ?>);">
                            <label for="image-upload" id="image-label"><?php echo app('translator')->get('Choose File'); ?></label>
                            <input type="file" name="maintenance_photo" id="image-upload" />
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="text-md-right text-left"><?php echo app('translator')->get('Maintenance Message'); ?>*</label>
                        <textarea name="maintenance_message" class="form-control summernote"
                            cols="10"><?php echo e($gs->maintenance); ?></textarea>
                    </div>

                    <div class="form-group text-center">
                        <button type="submit" class="btn btn-primary"><?php echo e(__('Update')); ?></button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('script'); ?>
<script>
    'use strict';
        $.uploadPreview({
            input_field: "#image-upload", // Default: .image-upload
            preview_box: "#image-preview", // Default: .image-preview
            label_field: "#image-label", // Default: .image-label
            label_default: "<?php echo e(__('Choose File')); ?>", // Default: Choose File
            label_selected: "<?php echo e(__('Update Image')); ?>", // Default: Change File
            no_label: false, // Default: false
            success_callback: null // Default: null
        });
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\car-service\project\resources\views/admin/generalsetting/maintainance.blade.php ENDPATH**/ ?>