

<?php $__env->startSection('title'); ?>
<?php echo app('translator')->get('Manage Blog Comment'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('breadcrumb'); ?>
<section class="section">
    <div class="section-header">
        <h1><?php echo app('translator')->get('Manage Blog Comment'); ?></h1>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<!-- Row -->
<div class="row">
    <div class="col-lg-12">
        <div class="card mb-4">
            <div class="table-responsive p-3">
                <table class="table align-items-center table-striped">
                    <tr>
                        <th><?php echo e(__('Blog')); ?></th>
                        <th><?php echo e(__('Name')); ?></th>
                        <th><?php echo e(__('Email')); ?></th>
                        <th><?php echo e(__('Comment')); ?></th>
                        <th><?php echo e(__('Action')); ?></th>
                    </tr>

                    <?php $__empty_1 = true; $__currentLoopData = $comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td data-label="<?php echo e(__('Blog')); ?>">
                            <?php echo e($item->blog->title); ?>

                        </td>
                        <td data-label="<?php echo e(__('Name')); ?>">
                            <?php echo e($item->name); ?>

                        </td>
                        <td data-label="<?php echo e(__('Email')); ?>">
                            <?php echo e($item->email); ?>

                        </td>
                        <td data-label="<?php echo e(__('Comment')); ?>">
                            <?php echo e($item->comment); ?>

                        </td>
                        <td data-label="<?php echo e(__('Action')); ?>">
                            <a href="javascript:void(0)" class="btn btn-danger  btn-sm remove mb-1"
                                data-route="<?php echo e(route('admin.blog.comment.delete', $item->id)); ?>" data-toggle="tooltip"
                                title="<?php echo app('translator')->get('Delete'); ?>"><i class="fas fa-trash"></i></a>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td class="text-center" colspan="100%"><?php echo app('translator')->get('No Data Found'); ?></td>
                    </tr>
                    <?php endif; ?>
                </table>
            </div>
        </div>
    </div>
    <!-- DataTable with Hover -->

</div>
<!--Row-->



<!-- Modal -->
<div class="modal fade" id="del" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <form action="" method="post">
            <?php echo csrf_field(); ?>
            <?php echo method_field('DELETE'); ?>
            <div class="modal-content">
                <div class="modal-body">
                    <h5 class="mt-3"><?php echo app('translator')->get('Are you sure to remove?'); ?></h5>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-dark" data-dismiss="modal"><?php echo app('translator')->get('Close'); ?></button>
                    <button type="submit" class="btn btn-danger"><?php echo app('translator')->get('Confirm'); ?></button>
                </div>
            </div>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('script'); ?>
<script>
    'use strict';
        $('.remove').on('click', function() {
            var route = $(this).data('route')
            $('#del').find('form').attr('action', route)
            $('#del').modal('show')
        })
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\charity-new\project\resources\views/admin/blog/comment.blade.php ENDPATH**/ ?>