

<?php $__env->startSection('title'); ?>
    <?php echo app('translator')->get('Currency'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('breadcrumb'); ?>
    <section class="section">
        <div class="section-header">
            <h1><?php echo app('translator')->get('Currency'); ?></h1>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-lg-12">
            <div class="card mb-4">
                <div class="card-header d-flex justify-content-end">
                    <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#add">
                        <i class="fas fa-plus"></i> <?php echo app('translator')->get('Add New'); ?>
                    </button>
                </div>
                <div class="table-responsive p-3">
                    <table class="table table-striped">
                        <tr>
                            <th><?php echo app('translator')->get('Code'); ?></th>
                            <th><?php echo app('translator')->get('Symbol'); ?></th>
                            <th><?php echo app('translator')->get('Value'); ?></th>
                            <th><?php echo app('translator')->get('Status'); ?></th>
                            <th><?php echo app('translator')->get('Default'); ?></th>
                            <th class="text-right"><?php echo app('translator')->get('Action'); ?></th>
                        </tr>
                        <?php $__empty_1 = true; $__currentLoopData = $currencies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $currency): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td data-label="<?php echo app('translator')->get('Code'); ?>">
                                    <?php echo e($currency->code); ?>

                                </td>
                                <td data-label="<?php echo app('translator')->get('Expired Date'); ?>">
                                    <?php echo e($currency->symbol); ?>

                                </td>
                                <td data-label="<?php echo app('translator')->get('Percentage(%)'); ?>">
                                    <?php echo e($currency->value); ?>

                                </td>

                                <td data-label="<?php echo app('translator')->get('Status'); ?>">
                                    <?php if($currency->status == 1): ?>
                                        <span class="badge badge-success"> <?php echo app('translator')->get('Active'); ?> </span>
                                    <?php else: ?>
                                        <span class="badge badge-danger"> <?php echo app('translator')->get('Deactive'); ?> </span>
                                    <?php endif; ?>
                                </td>

                                <td>
                                    <?php if($currency->default == 1): ?>
                                        <span class="badge badge-success"> <?php echo app('translator')->get('Default'); ?> </span>
                                    <?php else: ?>
                                        <div class="btn-group mb-2">
                                            <button class="btn btn-info btn-sm dropdown-toggle" type="button"
                                                data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                                <?php echo app('translator')->get('Set Default'); ?>
                                            </button>
                                            <div class="dropdown-menu" x-placement="bottom-start"
                                                style="position: absolute; transform: translate3d(0px, 29px, 0px); top: 0px; left: 0px; will-change: transform;">
                                                <a class="dropdown-item"
                                                    href="<?php echo e(route('admin.currency.default', $currency->id)); ?>"><?php echo app('translator')->get('Set Default'); ?></a>
                                            </div>
                                        </div>
                                    <?php endif; ?>
                                </td>

                                <td data-label="<?php echo app('translator')->get('Action'); ?>" class="text-right">
                                    <a href="javascript:void()" class="btn btn-primary btn-sm edit mb-1"
                                        data-route="<?php echo e(route('admin.currency.update', $currency->id)); ?>"
                                        data-item="<?php echo e($currency); ?>" data-toggle="tooltip" title="<?php echo app('translator')->get('Edit'); ?>"><i
                                            class="fas fa-edit"></i></a>
                                    <a href="javascript:void(0)" class="btn btn-danger btn-sm remove mb-1"
                                        data-id="<?php echo e($currency->id); ?>" data-toggle="tooltip" title="<?php echo app('translator')->get('Remove'); ?>">
                                        <i class="fas fa-trash"></i></a>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

                            <tr>
                                <td class="text-center" colspan="100%"><?php echo app('translator')->get('No Data Found'); ?></td>
                            </tr>
                        <?php endif; ?>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <div class="modal fade" id="add" tabindex="-1" role="dialog" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <form action="<?php echo e(route('admin.currency.store')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title"><?php echo app('translator')->get('Add new coupon'); ?></h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <div class="form-group">
                            <label><?php echo app('translator')->get('Code'); ?></label>
                            <input class="form-control" type="text" name="code">
                        </div>
                        <div class="form-group">
                            <label><?php echo app('translator')->get('Symbol'); ?></label>
                            <input class="form-control" type="text" name="symbol">
                        </div>
                        <div class="form-group">
                            <label><?php echo app('translator')->get('Value'); ?></label>
                            <input class="form-control" type="number" step="any" name="value">
                        </div>
                        <div class="form-group">
                            <label><?php echo app('translator')->get('Status'); ?></label>
                            <select name="status" class="form-control">
                                <option value="1"><?php echo app('translator')->get('Active'); ?></option>
                                <option value="0"><?php echo app('translator')->get('Inactive'); ?></option>
                            </select>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-dark" data-dismiss="modal"><?php echo app('translator')->get('Close'); ?></button>
                        <button type="submit" class="btn btn-primary"><?php echo app('translator')->get('Submit'); ?></button>
                    </div>
                </div>
            </form>
        </div>
    </div>

    <div class="modal fade" id="edit" tabindex="-1" role="dialog" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <form action="" method="POST">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title"><?php echo app('translator')->get('Edit Currency'); ?></h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <div class="form-group">
                            <label><?php echo app('translator')->get('Code'); ?></label>
                            <input class="form-control" type="text" name="code">
                        </div>
                        <div class="form-group">
                            <label><?php echo app('translator')->get('Symbol'); ?></label>
                            <input class="form-control" type="text" name="symbol">
                        </div>
                        <div class="form-group">
                            <label><?php echo app('translator')->get('Value'); ?></label>
                            <input class="form-control" type="number" step="any" name="value">
                        </div>
                        <div class="form-group">
                            <label><?php echo app('translator')->get('Status'); ?></label>
                            <select name="status" class="form-control">
                                <option value="1"><?php echo app('translator')->get('Active'); ?></option>
                                <option value="0"><?php echo app('translator')->get('Inactive'); ?></option>
                            </select>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-dark" data-dismiss="modal"><?php echo app('translator')->get('Close'); ?></button>
                        <button type="submit" class="btn btn-primary"><?php echo app('translator')->get('Submit'); ?></button>
                    </div>
                </div>
            </form>
        </div>
    </div>

    <div class="modal fade" id="removeMod" tabindex="-1" role="dialog">
        <div class="modal-dialog" role="document">
            <form action="<?php echo e(route('admin.currency.delete')); ?>" method="POST">
                <?php echo method_field('DELETE'); ?>
                <?php echo csrf_field(); ?>
                <input type="hidden" name="id">
                <div class="modal-content">
                    <div class="modal-body">
                        <h5><?php echo app('translator')->get('Are you sure to remove?'); ?></h5>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-dark" data-dismiss="modal"><?php echo app('translator')->get('Close'); ?></button>
                        <button type="submit" class="btn btn-danger"><?php echo app('translator')->get('Confirm'); ?></button>
                    </div>
                </div>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('script'); ?>
    <script>
        'use strict';
        $('.edit').on('click', function() {
            var data = $(this).data('item')

            $('#edit').find('input[name=code]').val(data.code)
            $('#edit').find('input[name=symbol]').val(data.symbol)
            $('#edit').find('input[name=value]').val(data.value)
            $('#edit').find('select[name=status]').val(data.status)
            $('#edit').find('form').attr('action', $(this).data('route'))
            $('#edit').modal('show')
        })
        $('.remove').on('click', function() {
            $('#removeMod').find('input[name=id]').val($(this).data('id'))
            $('#removeMod').modal('show')
        })
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\charity-new\project\resources\views/admin/currency/index.blade.php ENDPATH**/ ?>