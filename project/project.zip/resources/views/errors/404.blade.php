

<h1>@lang('NOT FOUND')</h1>